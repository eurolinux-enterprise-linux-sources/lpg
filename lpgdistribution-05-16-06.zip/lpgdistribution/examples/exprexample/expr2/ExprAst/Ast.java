package expr2.ExprAst;

import expr2.*;
import lpg.lpgjavaruntime.*;

public abstract class Ast
{
    protected IToken leftIToken,
                     rightIToken;
    public IToken getLeftIToken() { return leftIToken; }
    public IToken getRightIToken() { return rightIToken; }
    public IToken[] getPrecedingAdjuncts() { return leftIToken.getPrecedingAdjuncts(); }
    public IToken[] getFollowingAdjuncts() { return rightIToken.getPrecedingAdjuncts(); }
    public String toString()
    {
        PrsStream prsStream = leftIToken.getPrsStream();
        return new String(prsStream.getInputChars(),
                          leftIToken.getStartOffset(),
                          rightIToken.getEndOffset() - leftIToken.getStartOffset() + 1);
    }
    public Ast(IToken token) { this.leftIToken = this.rightIToken = token; }
    public Ast(IToken leftIToken, IToken rightIToken)
    {
        this.leftIToken = leftIToken;
        this.rightIToken = rightIToken;
    }
    void initialize() {}

    int value;
    public int getValue() { return value; }
    public void setValue(int value) { this.value = value; }
    /**
     * Since the Ast type has no children, any two instances of it are equal.
     */
    public boolean equals(Object o) { return o instanceof Ast; }
    public abstract int hashCode();
    public abstract void accept(Visitor v);
    public abstract void accept(ArgumentVisitor v, Object o);
    public abstract Object accept(ResultVisitor v);
    public abstract Object accept(ResultArgumentVisitor v, Object o);
}


