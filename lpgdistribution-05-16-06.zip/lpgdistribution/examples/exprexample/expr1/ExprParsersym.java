package expr1;

public interface ExprParsersym {
    public final static int
      TK_IntegerLiteral = 3,
      TK_PLUS = 1,
      TK_MULTIPLY = 2,
      TK_LPAREN = 4,
      TK_RPAREN = 5,
      TK_EOF_TOKEN = 6,
      TK_ERROR_TOKEN = 7;

      public final static String orderedTerminalSymbols[] = {
                 "",
                 "PLUS",
                 "MULTIPLY",
                 "IntegerLiteral",
                 "LPAREN",
                 "RPAREN",
                 "EOF_TOKEN",
                 "ERROR_TOKEN"
             };

    public final static boolean isValidForParser = true;
}
