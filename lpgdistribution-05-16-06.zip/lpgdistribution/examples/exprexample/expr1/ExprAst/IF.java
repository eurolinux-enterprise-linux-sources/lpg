package expr1.ExprAst;

/**
 * is implemented by:
 *<b>
 *<ul>
 *<li>F
 *<li>ParenExpr
 *</ul>
 *</b>
 */
public interface IF extends IT, IAstToken {}


