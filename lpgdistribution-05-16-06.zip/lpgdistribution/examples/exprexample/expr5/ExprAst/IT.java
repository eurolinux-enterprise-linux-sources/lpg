package expr5.ExprAst;

/**
 * is implemented by:
 *<b>
 *<ul>
 *<li>T
 *<li>F
 *<li>ParenExpr
 *</ul>
 *</b>
 */
public interface IT extends IE {}


