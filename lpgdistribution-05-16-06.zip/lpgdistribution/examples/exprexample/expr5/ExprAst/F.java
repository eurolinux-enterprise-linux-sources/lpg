package expr5.ExprAst;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 7:  F ::= IntegerLiteral
 *</b>
 */
public class F extends AstToken implements IF
{
    public F(IToken token) { super(token); initialize(); }

    public int hashCode()
    {
        return toString().hashCode();
    }

    public void accept(Visitor v)
    {
        v.preVisit(this);
        enter(v);
        v.postVisit(this);
    }

    public void enter(Visitor v)
    {
        v.visit(this);
        v.endVisit(this);
    }
}


