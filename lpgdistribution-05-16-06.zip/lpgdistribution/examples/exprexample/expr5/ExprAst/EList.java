package expr5.ExprAst;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 1:  EL ::= E
 *<li>Rule 2:  EL ::= EL , E
 *</b>
 */
public class EList extends AstList implements IEL
{
    public IE getEAt(int i) { return (IE) getElementAt(i); }

    public EList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public EList(IE _E, boolean leftRecursive)
    {
        super((Ast) _E, leftRecursive);
        initialize();
    }

    public void add(IE _E)
    {
        super.add((Ast) _E);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof EList)) return false;
        EList other = (EList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            IE element = getEAt(i);
            if (! element.equals(other.getEAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getEAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v)
    {
        v.preVisit(this);
        enter(v);
        v.postVisit(this);
    }
    public void enter(Visitor v)
    {
        boolean checkChildren = v.visit(this);
        if (checkChildren)
        {
            for (int i = 0; i < size(); i++)
            {
                IE element = getEAt(i);
                element.accept(v);
            }
        }
        v.endVisit(this);
    }
}


