package expr5.ExprAst;

/**
 * is implemented by:
 *<b>
 *<ul>
 *<li>E
 *<li>Err
 *<li>Err1
 *<li>T
 *<li>F
 *<li>ParenExpr
 *</ul>
 *</b>
 */
public interface IE1 extends IAstToken {}


