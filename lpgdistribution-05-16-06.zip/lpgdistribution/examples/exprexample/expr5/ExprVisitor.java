/*
 * Created on Feb 7, 2006
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package expr5;

import expr5.ExprAst.AbstractVisitor;
import expr5.ExprAst.Ast;
import expr5.ExprAst.E;
import expr5.ExprAst.EList;
import expr5.ExprAst.F;
import expr5.ExprAst.ParenExpr;
import expr5.ExprAst.T;
import lpg.lpgjavaruntime.*;
import java.util.Stack;

public class ExprVisitor extends AbstractVisitor {

	Stack evalStack = new Stack();
	
	public String visitAst(Ast ast) { 
		if (ast != null)
		{ 
			ast.accept(this);
			
			for (int j = 0; j < evalStack.size(); j++)
			{
				System.out.println("***The value of the expression is: " + getValue(j).toString());
			}
			return "****Success";
		}
		else
			return "****No Values";
	}
	
	public void unimplementedVisitor(String s) {
	    System.out.println("unimplemented visitor \"" + s + "\"");
	}

    public boolean visit(EList expr_list) { return true; }

    public void endVisit(EList expr_list) {  }

    public boolean visit(E expr) { return true; }
    public void endVisit(E expr) 
    {
        int t = ((Integer)evalStack.pop()).intValue();
        int e = ((Integer)evalStack.pop()).intValue();
        evalStack.push(new Integer(e + t));
    }

    public boolean visit(T expr) { return true; }
    public void endVisit(T expr) 
    {
        int f = ((Integer)evalStack.pop()).intValue();
        int t = ((Integer)evalStack.pop()).intValue();
        evalStack.push(new Integer(t * f));
    }

    public boolean visit(F expr) { return true; }
    public void endVisit(F expr) 
    {
        evalStack.push(new Integer(expr.getIToken().toString()));
    }

    public boolean visit(ParenExpr expr) { return true; }

    public void endVisit(ParenExpr expr) {  }

    public Integer getValue() { return (Integer)evalStack.peek();}

    public Integer getValue(int i) { return (Integer)evalStack.get(i);}
}
