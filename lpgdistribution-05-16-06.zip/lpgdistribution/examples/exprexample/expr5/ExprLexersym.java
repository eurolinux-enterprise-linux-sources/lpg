package expr5;

public interface ExprLexersym {
    public final static int
      Char_WSChar = 1,
      Char_Digit = 2,
      Char_Unused = 9,
      Char_EOF = 3,
      Char_Plus = 4,
      Char_Star = 5,
      Char_LeftParen = 6,
      Char_RightParen = 7,
      Char_Comma = 8;

      public final static String orderedTerminalSymbols[] = {
                 "",
                 "WSChar",
                 "Digit",
                 "EOF",
                 "Plus",
                 "Star",
                 "LeftParen",
                 "RightParen",
                 "Comma",
                 "Unused"
             };

    public final static boolean isValidForParser = true;
}
