package expr5;

import lpg.lpgjavaruntime.*;

public class ExprLexer extends LpgLexStream implements ExprParsersym, ExprLexersym, RuleAction
{
    private static ParseTable prs = new ExprLexerprs();
    private PrsStream prsStream;
    private LexParser lexParser = new LexParser(this, prs, this);

    public PrsStream getPrsStream() { return prsStream; }
    public int getToken(int i) { return lexParser.getToken(i); }
    public int getRhsFirstTokenIndex(int i) { return lexParser.getFirstToken(i); }
    public int getRhsLastTokenIndex(int i) { return lexParser.getLastToken(i); }

    public int getLeftSpan() { return lexParser.getFirstToken(); }
    public int getRightSpan() { return lexParser.getLastToken(); }

    public ExprLexer(String filename, int tab) throws java.io.IOException 
    {
        super(filename, tab);
    }

    public ExprLexer(char[] input_chars, String filename, int tab)
    {
        super(input_chars, filename, tab);
    }

    public ExprLexer(char[] input_chars, String filename)
    {
        this(input_chars, filename, 1);
    }

    public ExprLexer() {}

    public String[] orderedExportedSymbols() { return ExprParsersym.orderedTerminalSymbols; }
    public LexStream getLexStream() { return (LexStream) this; }

    public void lexer(PrsStream prsStream)
    {
        lexer(null, prsStream);
    }
    
    public void lexer(Monitor monitor, PrsStream prsStream)
    {
        if (getInputChars() == null)
            throw new NullPointerException("LexStream was not initialized");

        this.prsStream = prsStream;

        prsStream.makeToken(0, 0, 0); // Token list must start with a bad token
            
        lexParser.parseCharacters(monitor);  // Lex the input characters
            
        int i = getStreamIndex();
        prsStream.makeToken(i, i, TK_EOF_TOKEN); // and end with the end of file token
        prsStream.setStreamLength(prsStream.getSize());
            
        return;
    }

    final void makeToken(int kind)
    {
        int startOffset = getLeftSpan(),
            endOffset = getRightSpan();
        makeToken(startOffset, endOffset, kind);
    }

    public final int getKind(int i)  // Classify character at ith location
    {
        char c = (i >= getStreamLength() ? '\uffff' : getCharValue(i));
        return (c <  33			? Char_WSChar : 
        		c>= '0' && c <= '9' ? Char_Digit :
        		c == '+' 		? Char_Plus :
        		c == '*' 		? Char_Star :
        		c == '(' 		? Char_LeftParen :
        		c == ')' 		? Char_RightParen :
        		c == ',' 		? Char_Comma :
        		c == '\uffff' 	? Char_EOF : 
        						  Char_Unused);
    }

    public void ruleAction( int ruleNumber)
    {
        switch(ruleNumber)
        {
 
            //
            // Rule 1:  Token ::= IntegerLiteral
            //
            case 1: { 
                makeToken(TK_IntegerLiteral);
                break;
            }
     
            //
            // Rule 2:  Token ::= +
            //
            case 2: { 
                makeToken(TK_PLUS);
                break;
            }
     
            //
            // Rule 3:  Token ::= *
            //
            case 3: { 
                makeToken(TK_MULTIPLY);
                break;
            }
     
            //
            // Rule 4:  Token ::= (
            //
            case 4: { 
                makeToken(TK_LPAREN);
                break;
            }
     
            //
            // Rule 5:  Token ::= )
            //
            case 5: { 
                makeToken(TK_RPAREN);
                break;
            }
     
            //
            // Rule 6:  Token ::= ,
            //
            case 6: { 
                makeToken(TK_COMMA);
                break;
            }
    
    
            default:
                break;
        }
        return;
    }
}

