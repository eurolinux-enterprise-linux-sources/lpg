package expr3.ExprAst;

import expr3.*;
import lpg.lpgjavaruntime.*;

/**
 *<em>
 *<li>Rule 2:  E ::= T
 *</em>
 *<p>
 *<b>
 *<li>Rule 1:  E ::= E + T
 *</b>
 */
public class E extends Ast implements IE
{
    private ExprParser environment;
    public ExprParser getEnvironment() { return environment; }

    private IE _E;
    private IT _T;

    public IE getE() { return _E; }
    public IT getT() { return _T; }

    public E(ExprParser environment, IToken leftIToken, IToken rightIToken,
             IE _E,
             IT _T)
    {
        super(leftIToken, rightIToken);

        this.environment = environment;
        this._E = _E;
        this._T = _T;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof E)) return false;
        E other = (E) o;
        if (! _E.equals(other.getE())) return false;
        if (! _T.equals(other.getT())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getE().hashCode());
        hash = hash * 31 + (getT().hashCode());
        return hash;
    }

	void initialize()
    {
        setValue(((Ast) getE()).getValue() + ((Ast) getT()).getValue());
    }

}


