package expr4;

public interface ExprLexersym {
    public final static int
      Char_WSChar = 1,
      Char_Digit = 2,
      Char_Unused = 8,
      Char_EOF = 3,
      Char_Plus = 4,
      Char_Star = 5,
      Char_LeftParen = 6,
      Char_RightParen = 7;

      public final static String orderedTerminalSymbols[] = {
                 "",
                 "WSChar",
                 "Digit",
                 "EOF",
                 "Plus",
                 "Star",
                 "LeftParen",
                 "RightParen",
                 "Unused"
             };

    public final static boolean isValidForParser = true;
}
