package genericjavaparser;

class Ast
{
    public String ast = "****Success";
}
