//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import expandedjavaparser.*;
import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 78:  FieldDeclaration ::= Modifiersopt Type VariableDeclarators ;
 *</b>
 */
public class FieldDeclaration extends Ast implements IFieldDeclaration
{
    private JavaParser environment;
    public JavaParser getEnvironment() { return environment; }

    private ModifierList _Modifiersopt;
    private IType _Type;
    private VariableDeclaratorList _VariableDeclarators;

    public ModifierList getModifiersopt() { return _Modifiersopt; }
    public IType getType() { return _Type; }
    public VariableDeclaratorList getVariableDeclarators() { return _VariableDeclarators; }

    public FieldDeclaration(JavaParser environment, IToken leftIToken, IToken rightIToken,
                            ModifierList _Modifiersopt,
                            IType _Type,
                            VariableDeclaratorList _VariableDeclarators)
    {
        super(leftIToken, rightIToken);

        this.environment = environment;
        this._Modifiersopt = _Modifiersopt;
        this._Type = _Type;
        this._VariableDeclarators = _VariableDeclarators;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof FieldDeclaration)) return false;
        FieldDeclaration other = (FieldDeclaration) o;
        if (! _Modifiersopt.equals(other.getModifiersopt())) return false;
        if (! _Type.equals(other.getType())) return false;
        if (! _VariableDeclarators.equals(other.getVariableDeclarators())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getModifiersopt().hashCode());
        hash = hash * 31 + (getType().hashCode());
        hash = hash * 31 + (getVariableDeclarators().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }

    private IToken docComment;
    public IToken getDocComment() { return docComment; }
        
    public void initialize()
    {
        docComment = environment.getDocComment(getLeftIToken());
    }
}


