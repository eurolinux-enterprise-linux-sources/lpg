//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 165:  IfThenStatement ::= if ( Expression ) Statement$thenStmt
 *<li>Rule 166:  IfThenElseStatement ::= if ( Expression ) StatementNoShortIf$thenStmt else Statement$elseStmt
 *<li>Rule 167:  IfThenElseStatementNoShortIf ::= if ( Expression ) StatementNoShortIf$thenStmt else StatementNoShortIf$elseStmt
 *</b>
 */
public class IfStatement extends Ast implements IIfThenStatement, IIfThenElseStatement, IIfThenElseStatementNoShortIf
{
    private IExpression _Expression;
    private Ast _thenStmt;
    private Ast _elseStmt;

    public IExpression getExpression() { return _Expression; }
    public Ast getthenStmt() { return _thenStmt; }
    /**
     * The value returned by <b>getelseStmt</b> may be <b>null</b>
     */
    public Ast getelseStmt() { return _elseStmt; }

    public IfStatement(IToken leftIToken, IToken rightIToken,
                       IExpression _Expression,
                       Ast _thenStmt,
                       Ast _elseStmt)
    {
        super(leftIToken, rightIToken);

        this._Expression = _Expression;
        this._thenStmt = _thenStmt;
        this._elseStmt = _elseStmt;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof IfStatement)) return false;
        IfStatement other = (IfStatement) o;
        if (! _Expression.equals(other.getExpression())) return false;
        if (! _thenStmt.equals(other.getthenStmt())) return false;
        if (_elseStmt == null && other.getelseStmt() != null) return false;
        else if (! _elseStmt.equals(other.getelseStmt())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getExpression().hashCode());
        hash = hash * 31 + (getthenStmt().hashCode());
        hash = hash * 31 + (getelseStmt() == null ? 0 : getelseStmt().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


