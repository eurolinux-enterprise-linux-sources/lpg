//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 269:  RelationalExpression ::= RelationalExpression >= ShiftExpression
 *</b>
 */
public class GreaterEqualExpression extends Ast implements IRelationalExpression
{
    private IRelationalExpression _RelationalExpression;
    private IShiftExpression _ShiftExpression;

    public IRelationalExpression getRelationalExpression() { return _RelationalExpression; }
    public IShiftExpression getShiftExpression() { return _ShiftExpression; }

    public GreaterEqualExpression(IToken leftIToken, IToken rightIToken,
                                  IRelationalExpression _RelationalExpression,
                                  IShiftExpression _ShiftExpression)
    {
        super(leftIToken, rightIToken);

        this._RelationalExpression = _RelationalExpression;
        this._ShiftExpression = _ShiftExpression;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof GreaterEqualExpression)) return false;
        GreaterEqualExpression other = (GreaterEqualExpression) o;
        if (! _RelationalExpression.equals(other.getRelationalExpression())) return false;
        if (! _ShiftExpression.equals(other.getShiftExpression())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getRelationalExpression().hashCode());
        hash = hash * 31 + (getShiftExpression().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


