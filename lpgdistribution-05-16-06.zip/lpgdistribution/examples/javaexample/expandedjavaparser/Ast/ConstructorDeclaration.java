//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import expandedjavaparser.*;
import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 99:  ConstructorDeclaration ::= Modifiersopt ConstructorDeclarator Throwsopt ConstructorBody
 *</b>
 */
public class ConstructorDeclaration extends Ast implements IConstructorDeclaration
{
    private JavaParser environment;
    public JavaParser getEnvironment() { return environment; }

    private ModifierList _Modifiersopt;
    private ConstructorDeclarator _ConstructorDeclarator;
    private ClassTypeList _Throwsopt;
    private IConstructorBody _ConstructorBody;

    public ModifierList getModifiersopt() { return _Modifiersopt; }
    public ConstructorDeclarator getConstructorDeclarator() { return _ConstructorDeclarator; }
    public ClassTypeList getThrowsopt() { return _Throwsopt; }
    public IConstructorBody getConstructorBody() { return _ConstructorBody; }

    public ConstructorDeclaration(JavaParser environment, IToken leftIToken, IToken rightIToken,
                                  ModifierList _Modifiersopt,
                                  ConstructorDeclarator _ConstructorDeclarator,
                                  ClassTypeList _Throwsopt,
                                  IConstructorBody _ConstructorBody)
    {
        super(leftIToken, rightIToken);

        this.environment = environment;
        this._Modifiersopt = _Modifiersopt;
        this._ConstructorDeclarator = _ConstructorDeclarator;
        this._Throwsopt = _Throwsopt;
        this._ConstructorBody = _ConstructorBody;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ConstructorDeclaration)) return false;
        ConstructorDeclaration other = (ConstructorDeclaration) o;
        if (! _Modifiersopt.equals(other.getModifiersopt())) return false;
        if (! _ConstructorDeclarator.equals(other.getConstructorDeclarator())) return false;
        if (! _Throwsopt.equals(other.getThrowsopt())) return false;
        if (! _ConstructorBody.equals(other.getConstructorBody())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getModifiersopt().hashCode());
        hash = hash * 31 + (getConstructorDeclarator().hashCode());
        hash = hash * 31 + (getThrowsopt().hashCode());
        hash = hash * 31 + (getConstructorBody().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }

    private IToken docComment;
    public IToken getDocComment() { return docComment; }
        
    public void initialize()
    {
        docComment = environment.getDocComment(getLeftIToken());
    }
}


