//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 103:  ExplicitConstructorInvocation ::= this ( ArgumentListopt ) ;
 *<li>Rule 104:  ExplicitConstructorInvocation ::= Primary . this ( ArgumentListopt ) ;
 *</b>
 */
public class ThisCall extends Ast implements IExplicitConstructorInvocation
{
    private ExpressionList _ArgumentListopt;
    private IPrimary _Primary;

    public ExpressionList getArgumentListopt() { return _ArgumentListopt; }
    /**
     * The value returned by <b>getPrimary</b> may be <b>null</b>
     */
    public IPrimary getPrimary() { return _Primary; }

    public ThisCall(IToken leftIToken, IToken rightIToken,
                    ExpressionList _ArgumentListopt,
                    IPrimary _Primary)
    {
        super(leftIToken, rightIToken);

        this._ArgumentListopt = _ArgumentListopt;
        this._Primary = _Primary;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ThisCall)) return false;
        ThisCall other = (ThisCall) o;
        if (! _ArgumentListopt.equals(other.getArgumentListopt())) return false;
        if (_Primary == null && other.getPrimary() != null) return false;
        else if (! _Primary.equals(other.getPrimary())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getArgumentListopt().hashCode());
        hash = hash * 31 + (getPrimary() == null ? 0 : getPrimary().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


