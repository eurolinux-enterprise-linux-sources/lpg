//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 252:  CastExpression ::= ( Expression$Name ) UnaryExpressionNotPlusMinus
 *<li>Rule 253:  CastExpression ::= ( Name$Name Dims ) UnaryExpressionNotPlusMinus
 *</b>
 */
public class ClassCastExpression extends Ast implements ICastExpression
{
    private IExpression _Name;
    private IUnaryExpressionNotPlusMinus _UnaryExpressionNotPlusMinus;
    private DimList _Dims;

    public IExpression getName() { return _Name; }
    public IUnaryExpressionNotPlusMinus getUnaryExpressionNotPlusMinus() { return _UnaryExpressionNotPlusMinus; }
    /**
     * The value returned by <b>getDims</b> may be <b>null</b>
     */
    public DimList getDims() { return _Dims; }

    public ClassCastExpression(IToken leftIToken, IToken rightIToken,
                               IExpression _Name,
                               IUnaryExpressionNotPlusMinus _UnaryExpressionNotPlusMinus,
                               DimList _Dims)
    {
        super(leftIToken, rightIToken);

        this._Name = _Name;
        this._UnaryExpressionNotPlusMinus = _UnaryExpressionNotPlusMinus;
        this._Dims = _Dims;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ClassCastExpression)) return false;
        ClassCastExpression other = (ClassCastExpression) o;
        if (! _Name.equals(other.getName())) return false;
        if (! _UnaryExpressionNotPlusMinus.equals(other.getUnaryExpressionNotPlusMinus())) return false;
        if (_Dims == null && other.getDims() != null) return false;
        else if (! _Dims.equals(other.getDims())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getName().hashCode());
        hash = hash * 31 + (getUnaryExpressionNotPlusMinus().hashCode());
        hash = hash * 31 + (getDims() == null ? 0 : getDims().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


