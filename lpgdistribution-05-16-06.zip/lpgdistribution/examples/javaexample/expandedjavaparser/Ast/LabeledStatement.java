//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 155:  LabeledStatement ::= IDENTIFIER : Statement
 *<li>Rule 156:  LabeledStatementNoShortIf ::= IDENTIFIER : StatementNoShortIf$Statement
 *</b>
 */
public class LabeledStatement extends Ast implements ILabeledStatement, ILabeledStatementNoShortIf
{
    private Ast _Statement;

    public Ast getStatement() { return _Statement; }

    public LabeledStatement(IToken leftIToken, IToken rightIToken,
                            Ast _Statement)
    {
        super(leftIToken, rightIToken);

        this._Statement = _Statement;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof LabeledStatement)) return false;
        LabeledStatement other = (LabeledStatement) o;
        if (! _Statement.equals(other.getStatement())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getStatement().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


