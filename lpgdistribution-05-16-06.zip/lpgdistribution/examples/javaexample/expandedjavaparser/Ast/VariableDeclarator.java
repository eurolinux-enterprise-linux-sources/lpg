//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<em>
 *<li>Rule 81:  VariableDeclarator ::= VariableDeclaratorId
 *</em>
 *<p>
 *<b>
 *<li>Rule 82:  VariableDeclarator ::= VariableDeclaratorId = VariableInitializer
 *</b>
 */
public class VariableDeclarator extends Ast implements IVariableDeclarator
{
    private VariableDeclaratorId _VariableDeclaratorId;
    private IVariableInitializer _VariableInitializer;

    public VariableDeclaratorId getVariableDeclaratorId() { return _VariableDeclaratorId; }
    public IVariableInitializer getVariableInitializer() { return _VariableInitializer; }

    public VariableDeclarator(IToken leftIToken, IToken rightIToken,
                              VariableDeclaratorId _VariableDeclaratorId,
                              IVariableInitializer _VariableInitializer)
    {
        super(leftIToken, rightIToken);

        this._VariableDeclaratorId = _VariableDeclaratorId;
        this._VariableInitializer = _VariableInitializer;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof VariableDeclarator)) return false;
        VariableDeclarator other = (VariableDeclarator) o;
        if (! _VariableDeclaratorId.equals(other.getVariableDeclaratorId())) return false;
        if (! _VariableInitializer.equals(other.getVariableInitializer())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getVariableDeclaratorId().hashCode());
        hash = hash * 31 + (getVariableInitializer().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


