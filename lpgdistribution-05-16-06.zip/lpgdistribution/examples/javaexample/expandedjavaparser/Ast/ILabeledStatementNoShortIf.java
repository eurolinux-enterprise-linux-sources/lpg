//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>LabeledStatement</b>
 */
public interface ILabeledStatementNoShortIf extends IStatementNoShortIf {}


