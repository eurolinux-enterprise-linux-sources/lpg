//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 197:  CatchClause ::= catch ( FormalParameter ) Block
 *</b>
 */
public class CatchClause extends Ast implements ICatchClause
{
    private FormalParameter _FormalParameter;
    private Block _Block;

    public FormalParameter getFormalParameter() { return _FormalParameter; }
    public Block getBlock() { return _Block; }

    public CatchClause(IToken leftIToken, IToken rightIToken,
                       FormalParameter _FormalParameter,
                       Block _Block)
    {
        super(leftIToken, rightIToken);

        this._FormalParameter = _FormalParameter;
        this._Block = _Block;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof CatchClause)) return false;
        CatchClause other = (CatchClause) o;
        if (! _FormalParameter.equals(other.getFormalParameter())) return false;
        if (! _Block.equals(other.getBlock())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getFormalParameter().hashCode());
        hash = hash * 31 + (getBlock().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


