//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import expandedjavaparser.*;
import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 119:  AbstractMethodDeclaration ::= MethodHeader ;
 *</b>
 */
public class AbstractMethodDeclaration extends Ast implements IAbstractMethodDeclaration
{
    private JavaParser environment;
    public JavaParser getEnvironment() { return environment; }

    private IMethodHeader _MethodHeader;

    public IMethodHeader getMethodHeader() { return _MethodHeader; }

    public AbstractMethodDeclaration(JavaParser environment, IToken leftIToken, IToken rightIToken,
                                     IMethodHeader _MethodHeader)
    {
        super(leftIToken, rightIToken);

        this.environment = environment;
        this._MethodHeader = _MethodHeader;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof AbstractMethodDeclaration)) return false;
        AbstractMethodDeclaration other = (AbstractMethodDeclaration) o;
        if (! _MethodHeader.equals(other.getMethodHeader())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getMethodHeader().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }

    private IToken docComment;
    public IToken getDocComment() { return docComment; }
        
    public void initialize()
    {
        docComment = environment.getDocComment(getLeftIToken());
    }
}


