//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 288:  Assignment ::= LeftHandSide AssignmentOperator AssignmentExpression
 *</b>
 */
public class Assignment extends Ast implements IAssignment
{
    private ILeftHandSide _LeftHandSide;
    private IAssignmentOperator _AssignmentOperator;
    private IAssignmentExpression _AssignmentExpression;

    public ILeftHandSide getLeftHandSide() { return _LeftHandSide; }
    public IAssignmentOperator getAssignmentOperator() { return _AssignmentOperator; }
    public IAssignmentExpression getAssignmentExpression() { return _AssignmentExpression; }

    public Assignment(IToken leftIToken, IToken rightIToken,
                      ILeftHandSide _LeftHandSide,
                      IAssignmentOperator _AssignmentOperator,
                      IAssignmentExpression _AssignmentExpression)
    {
        super(leftIToken, rightIToken);

        this._LeftHandSide = _LeftHandSide;
        this._AssignmentOperator = _AssignmentOperator;
        this._AssignmentExpression = _AssignmentExpression;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof Assignment)) return false;
        Assignment other = (Assignment) o;
        if (! _LeftHandSide.equals(other.getLeftHandSide())) return false;
        if (! _AssignmentOperator.equals(other.getAssignmentOperator())) return false;
        if (! _AssignmentExpression.equals(other.getAssignmentExpression())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getLeftHandSide().hashCode());
        hash = hash * 31 + (getAssignmentOperator().hashCode());
        hash = hash * 31 + (getAssignmentExpression().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


