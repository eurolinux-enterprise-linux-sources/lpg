//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 87:  MethodHeader ::= Modifiersopt Type MethodDeclarator Throwsopt
 *</b>
 */
public class TypedMethodHeader extends Ast implements IMethodHeader
{
    private ModifierList _Modifiersopt;
    private IType _Type;
    private MethodDeclarator _MethodDeclarator;
    private ClassTypeList _Throwsopt;

    public ModifierList getModifiersopt() { return _Modifiersopt; }
    public IType getType() { return _Type; }
    public MethodDeclarator getMethodDeclarator() { return _MethodDeclarator; }
    public ClassTypeList getThrowsopt() { return _Throwsopt; }

    public TypedMethodHeader(IToken leftIToken, IToken rightIToken,
                             ModifierList _Modifiersopt,
                             IType _Type,
                             MethodDeclarator _MethodDeclarator,
                             ClassTypeList _Throwsopt)
    {
        super(leftIToken, rightIToken);

        this._Modifiersopt = _Modifiersopt;
        this._Type = _Type;
        this._MethodDeclarator = _MethodDeclarator;
        this._Throwsopt = _Throwsopt;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof TypedMethodHeader)) return false;
        TypedMethodHeader other = (TypedMethodHeader) o;
        if (! _Modifiersopt.equals(other.getModifiersopt())) return false;
        if (! _Type.equals(other.getType())) return false;
        if (! _MethodDeclarator.equals(other.getMethodDeclarator())) return false;
        if (! _Throwsopt.equals(other.getThrowsopt())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getModifiersopt().hashCode());
        hash = hash * 31 + (getType().hashCode());
        hash = hash * 31 + (getMethodDeclarator().hashCode());
        hash = hash * 31 + (getThrowsopt().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


