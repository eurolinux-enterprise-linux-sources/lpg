//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 83:  VariableDeclaratorId ::= IDENTIFIER Dimsopt
 *</b>
 */
public class VariableDeclaratorId extends Ast implements IVariableDeclaratorId
{
    private DimList _Dimsopt;

    public DimList getDimsopt() { return _Dimsopt; }

    public VariableDeclaratorId(IToken leftIToken, IToken rightIToken,
                                DimList _Dimsopt)
    {
        super(leftIToken, rightIToken);

        this._Dimsopt = _Dimsopt;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof VariableDeclaratorId)) return false;
        VariableDeclaratorId other = (VariableDeclaratorId) o;
        if (! _Dimsopt.equals(other.getDimsopt())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getDimsopt().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


