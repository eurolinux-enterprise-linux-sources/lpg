//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>ArrayCreationExpression</b>
 */
public interface IArrayCreationExpression extends IPrimary {}


