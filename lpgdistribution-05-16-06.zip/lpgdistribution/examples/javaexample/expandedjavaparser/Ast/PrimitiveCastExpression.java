//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 251:  CastExpression ::= ( PrimitiveType Dimsopt ) UnaryExpression
 *</b>
 */
public class PrimitiveCastExpression extends Ast implements ICastExpression
{
    private IPrimitiveType _PrimitiveType;
    private DimList _Dimsopt;
    private IUnaryExpression _UnaryExpression;

    public IPrimitiveType getPrimitiveType() { return _PrimitiveType; }
    public DimList getDimsopt() { return _Dimsopt; }
    public IUnaryExpression getUnaryExpression() { return _UnaryExpression; }

    public PrimitiveCastExpression(IToken leftIToken, IToken rightIToken,
                                   IPrimitiveType _PrimitiveType,
                                   DimList _Dimsopt,
                                   IUnaryExpression _UnaryExpression)
    {
        super(leftIToken, rightIToken);

        this._PrimitiveType = _PrimitiveType;
        this._Dimsopt = _Dimsopt;
        this._UnaryExpression = _UnaryExpression;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof PrimitiveCastExpression)) return false;
        PrimitiveCastExpression other = (PrimitiveCastExpression) o;
        if (! _PrimitiveType.equals(other.getPrimitiveType())) return false;
        if (! _Dimsopt.equals(other.getDimsopt())) return false;
        if (! _UnaryExpression.equals(other.getUnaryExpression())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getPrimitiveType().hashCode());
        hash = hash * 31 + (getDimsopt().hashCode());
        hash = hash * 31 + (getUnaryExpression().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


