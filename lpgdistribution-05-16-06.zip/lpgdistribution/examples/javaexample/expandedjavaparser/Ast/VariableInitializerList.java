//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 121:  VariableInitializers ::= VariableInitializer
 *<li>Rule 122:  VariableInitializers ::= VariableInitializers , VariableInitializer
 *<li>Rule 344:  VariableInitializersopt ::= $Empty
 *<li>Rule 345:  VariableInitializersopt ::= VariableInitializers
 *</b>
 */
public class VariableInitializerList extends AstList implements IVariableInitializers, IVariableInitializersopt
{
    public IVariableInitializer getVariableInitializerAt(int i) { return (IVariableInitializer) getElementAt(i); }

    public VariableInitializerList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public VariableInitializerList(IVariableInitializer _VariableInitializer, boolean leftRecursive)
    {
        super((Ast) _VariableInitializer, leftRecursive);
        initialize();
    }

    public void add(IVariableInitializer _VariableInitializer)
    {
        super.add((Ast) _VariableInitializer);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof VariableInitializerList)) return false;
        VariableInitializerList other = (VariableInitializerList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            IVariableInitializer element = getVariableInitializerAt(i);
            if (! element.equals(other.getVariableInitializerAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getVariableInitializerAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) getVariableInitializerAt(i).accept(v); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getVariableInitializerAt(i).accept(v, o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) getVariableInitializerAt(i).accept(v); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getVariableInitializerAt(i).accept(v, o); return null; }
}


