//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>SwitchStatement</b>
 */
public interface ISwitchStatement extends IStatementWithoutTrailingSubstatement {}


