//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>FieldDeclaration</b>
 */
public interface IFieldDeclaration extends IClassMemberDeclaration, IConstantDeclaration {}


