//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<em>
 *<li>Rule 284:  ConditionalExpression ::= ConditionalOrExpression
 *</em>
 *<p>
 *<b>
 *<li>Rule 285:  ConditionalExpression ::= ConditionalOrExpression ? Expression : ConditionalExpression
 *</b>
 */
public class ConditionalExpression extends Ast implements IConditionalExpression
{
    private IConditionalOrExpression _ConditionalOrExpression;
    private IExpression _Expression;
    private IConditionalExpression _ConditionalExpression;

    public IConditionalOrExpression getConditionalOrExpression() { return _ConditionalOrExpression; }
    public IExpression getExpression() { return _Expression; }
    public IConditionalExpression getConditionalExpression() { return _ConditionalExpression; }

    public ConditionalExpression(IToken leftIToken, IToken rightIToken,
                                 IConditionalOrExpression _ConditionalOrExpression,
                                 IExpression _Expression,
                                 IConditionalExpression _ConditionalExpression)
    {
        super(leftIToken, rightIToken);

        this._ConditionalOrExpression = _ConditionalOrExpression;
        this._Expression = _Expression;
        this._ConditionalExpression = _ConditionalExpression;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ConditionalExpression)) return false;
        ConditionalExpression other = (ConditionalExpression) o;
        if (! _ConditionalOrExpression.equals(other.getConditionalOrExpression())) return false;
        if (! _Expression.equals(other.getExpression())) return false;
        if (! _ConditionalExpression.equals(other.getConditionalExpression())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getConditionalOrExpression().hashCode());
        hash = hash * 31 + (getExpression().hashCode());
        hash = hash * 31 + (getConditionalExpression().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


