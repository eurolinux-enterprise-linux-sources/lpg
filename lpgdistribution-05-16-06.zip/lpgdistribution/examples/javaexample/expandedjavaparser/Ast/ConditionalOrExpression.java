//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<em>
 *<li>Rule 282:  ConditionalOrExpression ::= ConditionalAndExpression
 *</em>
 *<p>
 *<b>
 *<li>Rule 283:  ConditionalOrExpression ::= ConditionalOrExpression || ConditionalAndExpression
 *</b>
 */
public class ConditionalOrExpression extends Ast implements IConditionalOrExpression
{
    private IConditionalOrExpression _ConditionalOrExpression;
    private IConditionalAndExpression _ConditionalAndExpression;

    public IConditionalOrExpression getConditionalOrExpression() { return _ConditionalOrExpression; }
    public IConditionalAndExpression getConditionalAndExpression() { return _ConditionalAndExpression; }

    public ConditionalOrExpression(IToken leftIToken, IToken rightIToken,
                                   IConditionalOrExpression _ConditionalOrExpression,
                                   IConditionalAndExpression _ConditionalAndExpression)
    {
        super(leftIToken, rightIToken);

        this._ConditionalOrExpression = _ConditionalOrExpression;
        this._ConditionalAndExpression = _ConditionalAndExpression;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ConditionalOrExpression)) return false;
        ConditionalOrExpression other = (ConditionalOrExpression) o;
        if (! _ConditionalOrExpression.equals(other.getConditionalOrExpression())) return false;
        if (! _ConditionalAndExpression.equals(other.getConditionalAndExpression())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getConditionalOrExpression().hashCode());
        hash = hash * 31 + (getConditionalAndExpression().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


