//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 89:  MethodDeclarator ::= IDENTIFIER ( FormalParameterListopt ) Dimsopt
 *</b>
 */
public class MethodDeclarator extends Ast implements IMethodDeclarator
{
    private FormalParameterList _FormalParameterListopt;
    private DimList _Dimsopt;

    public FormalParameterList getFormalParameterListopt() { return _FormalParameterListopt; }
    public DimList getDimsopt() { return _Dimsopt; }

    public MethodDeclarator(IToken leftIToken, IToken rightIToken,
                            FormalParameterList _FormalParameterListopt,
                            DimList _Dimsopt)
    {
        super(leftIToken, rightIToken);

        this._FormalParameterListopt = _FormalParameterListopt;
        this._Dimsopt = _Dimsopt;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof MethodDeclarator)) return false;
        MethodDeclarator other = (MethodDeclarator) o;
        if (! _FormalParameterListopt.equals(other.getFormalParameterListopt())) return false;
        if (! _Dimsopt.equals(other.getDimsopt())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getFormalParameterListopt().hashCode());
        hash = hash * 31 + (getDimsopt().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


