//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 185:  ForUpdate ::= StatementExpressionList
 *<li>Rule 186:  StatementExpressionList ::= StatementExpression
 *<li>Rule 187:  StatementExpressionList ::= StatementExpressionList , StatementExpression
 *<li>Rule 338:  ForUpdateopt ::= $Empty
 *<li>Rule 339:  ForUpdateopt ::= ForUpdate
 *</b>
 */
public class StatementExpressionList extends AstList implements IForUpdate, IStatementExpressionList, IForUpdateopt
{
    public IStatementExpression getStatementExpressionAt(int i) { return (IStatementExpression) getElementAt(i); }

    public StatementExpressionList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public StatementExpressionList(IStatementExpression _StatementExpression, boolean leftRecursive)
    {
        super((Ast) _StatementExpression, leftRecursive);
        initialize();
    }

    public void add(IStatementExpression _StatementExpression)
    {
        super.add((Ast) _StatementExpression);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof StatementExpressionList)) return false;
        StatementExpressionList other = (StatementExpressionList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            IStatementExpression element = getStatementExpressionAt(i);
            if (! element.equals(other.getStatementExpressionAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getStatementExpressionAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) getStatementExpressionAt(i).accept(v); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getStatementExpressionAt(i).accept(v, o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) getStatementExpressionAt(i).accept(v); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getStatementExpressionAt(i).accept(v, o); return null; }
}


