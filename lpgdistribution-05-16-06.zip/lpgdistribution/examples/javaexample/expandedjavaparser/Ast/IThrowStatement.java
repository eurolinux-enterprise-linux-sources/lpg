//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>ThrowStatement</b>
 */
public interface IThrowStatement extends IStatementWithoutTrailingSubstatement {}


