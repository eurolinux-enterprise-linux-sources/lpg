//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 38:  TypeDeclarations ::= TypeDeclaration
 *<li>Rule 39:  TypeDeclarations ::= TypeDeclarations TypeDeclaration
 *<li>Rule 316:  TypeDeclarationsopt ::= $Empty
 *<li>Rule 317:  TypeDeclarationsopt ::= TypeDeclarations
 *</b>
 */
public class TypeDeclarationList extends AstList implements ITypeDeclarations, ITypeDeclarationsopt
{
    public ITypeDeclaration getTypeDeclarationAt(int i) { return (ITypeDeclaration) getElementAt(i); }

    public TypeDeclarationList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public TypeDeclarationList(ITypeDeclaration _TypeDeclaration, boolean leftRecursive)
    {
        super((Ast) _TypeDeclaration, leftRecursive);
        initialize();
    }

    public void add(ITypeDeclaration _TypeDeclaration)
    {
        super.add((Ast) _TypeDeclaration);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof TypeDeclarationList)) return false;
        TypeDeclarationList other = (TypeDeclarationList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            ITypeDeclaration element = getTypeDeclarationAt(i);
            if (! element.equals(other.getTypeDeclarationAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getTypeDeclarationAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) getTypeDeclarationAt(i).accept(v); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getTypeDeclarationAt(i).accept(v, o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) getTypeDeclarationAt(i).accept(v); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getTypeDeclarationAt(i).accept(v, o); return null; }
}


