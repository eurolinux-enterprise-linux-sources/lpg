//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 1:  Literal ::= IntegerLiteral
 *</b>
 */
public class IntegerLiteral extends AstToken implements ILiteral
{
    public IntegerLiteral(IToken token) { super(token); initialize(); }

    public int hashCode()
    {
        return toString().hashCode();
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


