//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 174:  SwitchLabels ::= SwitchLabel
 *<li>Rule 175:  SwitchLabels ::= SwitchLabels SwitchLabel
 *<li>Rule 346:  SwitchLabelsopt ::= $Empty
 *<li>Rule 347:  SwitchLabelsopt ::= SwitchLabels
 *</b>
 */
public class SwitchLabelList extends AstList implements ISwitchLabels, ISwitchLabelsopt
{
    public ISwitchLabel getSwitchLabelAt(int i) { return (ISwitchLabel) getElementAt(i); }

    public SwitchLabelList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public SwitchLabelList(ISwitchLabel _SwitchLabel, boolean leftRecursive)
    {
        super((Ast) _SwitchLabel, leftRecursive);
        initialize();
    }

    public void add(ISwitchLabel _SwitchLabel)
    {
        super.add((Ast) _SwitchLabel);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof SwitchLabelList)) return false;
        SwitchLabelList other = (SwitchLabelList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            ISwitchLabel element = getSwitchLabelAt(i);
            if (! element.equals(other.getSwitchLabelAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getSwitchLabelAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) getSwitchLabelAt(i).accept(v); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getSwitchLabelAt(i).accept(v, o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) getSwitchLabelAt(i).accept(v); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getSwitchLabelAt(i).accept(v, o); return null; }
}


