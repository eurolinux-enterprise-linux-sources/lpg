//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 35:  CompilationUnit ::= PackageDeclarationopt ImportDeclarationsopt TypeDeclarationsopt
 *</b>
 */
public class CompilationUnit extends Ast implements ICompilationUnit
{
    private PackageDeclaration _PackageDeclarationopt;
    private ImportDeclarationList _ImportDeclarationsopt;
    private TypeDeclarationList _TypeDeclarationsopt;

    /**
     * The value returned by <b>getPackageDeclarationopt</b> may be <b>null</b>
     */
    public PackageDeclaration getPackageDeclarationopt() { return _PackageDeclarationopt; }
    public ImportDeclarationList getImportDeclarationsopt() { return _ImportDeclarationsopt; }
    public TypeDeclarationList getTypeDeclarationsopt() { return _TypeDeclarationsopt; }

    public CompilationUnit(IToken leftIToken, IToken rightIToken,
                           PackageDeclaration _PackageDeclarationopt,
                           ImportDeclarationList _ImportDeclarationsopt,
                           TypeDeclarationList _TypeDeclarationsopt)
    {
        super(leftIToken, rightIToken);

        this._PackageDeclarationopt = _PackageDeclarationopt;
        this._ImportDeclarationsopt = _ImportDeclarationsopt;
        this._TypeDeclarationsopt = _TypeDeclarationsopt;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof CompilationUnit)) return false;
        CompilationUnit other = (CompilationUnit) o;
        if (_PackageDeclarationopt == null && other.getPackageDeclarationopt() != null) return false;
        else if (! _PackageDeclarationopt.equals(other.getPackageDeclarationopt())) return false;
        if (! _ImportDeclarationsopt.equals(other.getImportDeclarationsopt())) return false;
        if (! _TypeDeclarationsopt.equals(other.getTypeDeclarationsopt())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getPackageDeclarationopt() == null ? 0 : getPackageDeclarationopt().hashCode());
        hash = hash * 31 + (getImportDeclarationsopt().hashCode());
        hash = hash * 31 + (getTypeDeclarationsopt().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


