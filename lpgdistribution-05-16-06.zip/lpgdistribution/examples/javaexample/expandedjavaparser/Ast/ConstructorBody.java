//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<em>
 *<li>Rule 101:  ConstructorBody ::= Block
 *</em>
 *<p>
 *<b>
 *<li>Rule 102:  ConstructorBody ::= { ExplicitConstructorInvocation BlockStatementsopt }
 *</b>
 */
public class ConstructorBody extends Ast implements IConstructorBody
{
    private IExplicitConstructorInvocation _ExplicitConstructorInvocation;
    private BlockStatementList _BlockStatementsopt;

    public IExplicitConstructorInvocation getExplicitConstructorInvocation() { return _ExplicitConstructorInvocation; }
    public BlockStatementList getBlockStatementsopt() { return _BlockStatementsopt; }

    public ConstructorBody(IToken leftIToken, IToken rightIToken,
                           IExplicitConstructorInvocation _ExplicitConstructorInvocation,
                           BlockStatementList _BlockStatementsopt)
    {
        super(leftIToken, rightIToken);

        this._ExplicitConstructorInvocation = _ExplicitConstructorInvocation;
        this._BlockStatementsopt = _BlockStatementsopt;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ConstructorBody)) return false;
        ConstructorBody other = (ConstructorBody) o;
        if (! _ExplicitConstructorInvocation.equals(other.getExplicitConstructorInvocation())) return false;
        if (! _BlockStatementsopt.equals(other.getBlockStatementsopt())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getExplicitConstructorInvocation().hashCode());
        hash = hash * 31 + (getBlockStatementsopt().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


