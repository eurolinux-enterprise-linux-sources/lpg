//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 190:  ReturnStatement ::= return Expressionopt ;
 *</b>
 */
public class ReturnStatement extends Ast implements IReturnStatement
{
    private IExpressionopt _Expressionopt;

    /**
     * The value returned by <b>getExpressionopt</b> may be <b>null</b>
     */
    public IExpressionopt getExpressionopt() { return _Expressionopt; }

    public ReturnStatement(IToken leftIToken, IToken rightIToken,
                           IExpressionopt _Expressionopt)
    {
        super(leftIToken, rightIToken);

        this._Expressionopt = _Expressionopt;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ReturnStatement)) return false;
        ReturnStatement other = (ReturnStatement) o;
        if (_Expressionopt == null && other.getExpressionopt() != null) return false;
        else if (! _Expressionopt.equals(other.getExpressionopt())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getExpressionopt() == null ? 0 : getExpressionopt().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


