//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 168:  SwitchStatement ::= switch ( Expression ) SwitchBlock
 *</b>
 */
public class SwitchStatement extends Ast implements ISwitchStatement
{
    private IExpression _Expression;
    private SwitchBlock _SwitchBlock;

    public IExpression getExpression() { return _Expression; }
    public SwitchBlock getSwitchBlock() { return _SwitchBlock; }

    public SwitchStatement(IToken leftIToken, IToken rightIToken,
                           IExpression _Expression,
                           SwitchBlock _SwitchBlock)
    {
        super(leftIToken, rightIToken);

        this._Expression = _Expression;
        this._SwitchBlock = _SwitchBlock;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof SwitchStatement)) return false;
        SwitchStatement other = (SwitchStatement) o;
        if (! _Expression.equals(other.getExpression())) return false;
        if (! _SwitchBlock.equals(other.getSwitchBlock())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getExpression().hashCode());
        hash = hash * 31 + (getSwitchBlock().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


