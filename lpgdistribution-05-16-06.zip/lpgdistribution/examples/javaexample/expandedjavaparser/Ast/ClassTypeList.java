//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 93:  Throws ::= throws ClassTypeList
 *<li>Rule 94:  ClassTypeList ::= ClassType
 *<li>Rule 95:  ClassTypeList ::= ClassTypeList , ClassType
 *<li>Rule 328:  Throwsopt ::= $Empty
 *<li>Rule 329:  Throwsopt ::= Throws
 *</b>
 */
public class ClassTypeList extends AstList implements IThrows, IClassTypeList, IThrowsopt
{
    public IClassType getClassTypeAt(int i) { return (IClassType) getElementAt(i); }

    public ClassTypeList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public ClassTypeList(IClassType _ClassType, boolean leftRecursive)
    {
        super((Ast) _ClassType, leftRecursive);
        initialize();
    }

    public void add(IClassType _ClassType)
    {
        super.add((Ast) _ClassType);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof ClassTypeList)) return false;
        ClassTypeList other = (ClassTypeList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            IClassType element = getClassTypeAt(i);
            if (! element.equals(other.getClassTypeAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getClassTypeAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) getClassTypeAt(i).accept(v); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getClassTypeAt(i).accept(v, o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) getClassTypeAt(i).accept(v); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getClassTypeAt(i).accept(v, o); return null; }
}


