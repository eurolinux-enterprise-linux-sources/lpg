//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 120:  ArrayInitializer ::= { VariableInitializersopt Commaopt }
 *</b>
 */
public class ArrayInitializer extends Ast implements IArrayInitializer
{
    private VariableInitializerList _VariableInitializersopt;
    private Commaopt _Commaopt;

    public VariableInitializerList getVariableInitializersopt() { return _VariableInitializersopt; }
    /**
     * The value returned by <b>getCommaopt</b> may be <b>null</b>
     */
    public Commaopt getCommaopt() { return _Commaopt; }

    public ArrayInitializer(IToken leftIToken, IToken rightIToken,
                            VariableInitializerList _VariableInitializersopt,
                            Commaopt _Commaopt)
    {
        super(leftIToken, rightIToken);

        this._VariableInitializersopt = _VariableInitializersopt;
        this._Commaopt = _Commaopt;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ArrayInitializer)) return false;
        ArrayInitializer other = (ArrayInitializer) o;
        if (! _VariableInitializersopt.equals(other.getVariableInitializersopt())) return false;
        if (_Commaopt == null && other.getCommaopt() != null) return false;
        else if (! _Commaopt.equals(other.getCommaopt())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getVariableInitializersopt().hashCode());
        hash = hash * 31 + (getCommaopt() == null ? 0 : getCommaopt().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


