//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 211:  ClassInstanceCreationExpression ::= new ClassType ( ArgumentListopt ) ClassBodyopt
 *<li>Rule 212:  ClassInstanceCreationExpression ::= Primary$expression . new SimpleName$ClassType ( ArgumentListopt ) ClassBodyopt
 *<li>Rule 213:  ClassInstanceCreationExpression ::= Name$expression . new SimpleName$ClassType ( ArgumentListopt ) ClassBodyopt
 *</b>
 */
public class ClassInstanceCreationExpression extends Ast implements IClassInstanceCreationExpression
{
    private IClassType _ClassType;
    private ExpressionList _ArgumentListopt;
    private ClassBody _ClassBodyopt;
    private IPostfixExpression _expression;

    public IClassType getClassType() { return _ClassType; }
    public ExpressionList getArgumentListopt() { return _ArgumentListopt; }
    /**
     * The value returned by <b>getClassBodyopt</b> may be <b>null</b>
     */
    public ClassBody getClassBodyopt() { return _ClassBodyopt; }
    /**
     * The value returned by <b>getexpression</b> may be <b>null</b>
     */
    public IPostfixExpression getexpression() { return _expression; }

    public ClassInstanceCreationExpression(IToken leftIToken, IToken rightIToken,
                                           IClassType _ClassType,
                                           ExpressionList _ArgumentListopt,
                                           ClassBody _ClassBodyopt,
                                           IPostfixExpression _expression)
    {
        super(leftIToken, rightIToken);

        this._ClassType = _ClassType;
        this._ArgumentListopt = _ArgumentListopt;
        this._ClassBodyopt = _ClassBodyopt;
        this._expression = _expression;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ClassInstanceCreationExpression)) return false;
        ClassInstanceCreationExpression other = (ClassInstanceCreationExpression) o;
        if (! _ClassType.equals(other.getClassType())) return false;
        if (! _ArgumentListopt.equals(other.getArgumentListopt())) return false;
        if (_ClassBodyopt == null && other.getClassBodyopt() != null) return false;
        else if (! _ClassBodyopt.equals(other.getClassBodyopt())) return false;
        if (_expression == null && other.getexpression() != null) return false;
        else if (! _expression.equals(other.getexpression())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getClassType().hashCode());
        hash = hash * 31 + (getArgumentListopt().hashCode());
        hash = hash * 31 + (getClassBodyopt() == null ? 0 : getClassBodyopt().hashCode());
        hash = hash * 31 + (getexpression() == null ? 0 : getexpression().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


