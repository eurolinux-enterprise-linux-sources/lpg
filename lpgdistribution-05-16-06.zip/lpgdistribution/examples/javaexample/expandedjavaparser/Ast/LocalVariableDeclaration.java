//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import expandedjavaparser.*;
import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 130:  LocalVariableDeclaration ::= Modifiers Type VariableDeclarators
 *<li>Rule 131:  LocalVariableDeclaration ::= Type VariableDeclarators
 *</b>
 */
public class LocalVariableDeclaration extends Ast implements ILocalVariableDeclaration
{
    private JavaParser environment;
    public JavaParser getEnvironment() { return environment; }

    private ModifierList _Modifiers;
    private IType _Type;
    private VariableDeclaratorList _VariableDeclarators;

    /**
     * The value returned by <b>getModifiers</b> may be <b>null</b>
     */
    public ModifierList getModifiers() { return _Modifiers; }
    public IType getType() { return _Type; }
    public VariableDeclaratorList getVariableDeclarators() { return _VariableDeclarators; }

    public LocalVariableDeclaration(JavaParser environment, IToken leftIToken, IToken rightIToken,
                                    ModifierList _Modifiers,
                                    IType _Type,
                                    VariableDeclaratorList _VariableDeclarators)
    {
        super(leftIToken, rightIToken);

        this.environment = environment;
        this._Modifiers = _Modifiers;
        this._Type = _Type;
        this._VariableDeclarators = _VariableDeclarators;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof LocalVariableDeclaration)) return false;
        LocalVariableDeclaration other = (LocalVariableDeclaration) o;
        if (_Modifiers == null && other.getModifiers() != null) return false;
        else if (! _Modifiers.equals(other.getModifiers())) return false;
        if (! _Type.equals(other.getType())) return false;
        if (! _VariableDeclarators.equals(other.getVariableDeclarators())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getModifiers() == null ? 0 : getModifiers().hashCode());
        hash = hash * 31 + (getType().hashCode());
        hash = hash * 31 + (getVariableDeclarators().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }

        public void initialize()
        {
            if (_Modifiers == null)
            {
                IToken left = environment.getLeftIToken(),
                       right = environment.getPrevious(left);
                _Modifiers = new ModifierList(left, right, true);
            }
        }
}


