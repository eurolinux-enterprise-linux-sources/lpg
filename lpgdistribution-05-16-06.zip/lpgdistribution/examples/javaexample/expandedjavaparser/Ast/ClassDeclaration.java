//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import expandedjavaparser.*;
import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 61:  ClassDeclaration ::= Modifiersopt class IDENTIFIER$Name Superopt Interfacesopt ClassBody
 *</b>
 */
public class ClassDeclaration extends Ast implements IClassDeclaration
{
    private JavaParser environment;
    public JavaParser getEnvironment() { return environment; }

    private ModifierList _Modifiersopt;
    private AstToken _Name;
    private Super _Superopt;
    private InterfaceTypeList _Interfacesopt;
    private ClassBody _ClassBody;

    public ModifierList getModifiersopt() { return _Modifiersopt; }
    public AstToken getName() { return _Name; }
    /**
     * The value returned by <b>getSuperopt</b> may be <b>null</b>
     */
    public Super getSuperopt() { return _Superopt; }
    public InterfaceTypeList getInterfacesopt() { return _Interfacesopt; }
    public ClassBody getClassBody() { return _ClassBody; }

    public ClassDeclaration(JavaParser environment, IToken leftIToken, IToken rightIToken,
                            ModifierList _Modifiersopt,
                            AstToken _Name,
                            Super _Superopt,
                            InterfaceTypeList _Interfacesopt,
                            ClassBody _ClassBody)
    {
        super(leftIToken, rightIToken);

        this.environment = environment;
        this._Modifiersopt = _Modifiersopt;
        this._Name = _Name;
        this._Superopt = _Superopt;
        this._Interfacesopt = _Interfacesopt;
        this._ClassBody = _ClassBody;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ClassDeclaration)) return false;
        ClassDeclaration other = (ClassDeclaration) o;
        if (! _Modifiersopt.equals(other.getModifiersopt())) return false;
        if (! _Name.equals(other.getName())) return false;
        if (_Superopt == null && other.getSuperopt() != null) return false;
        else if (! _Superopt.equals(other.getSuperopt())) return false;
        if (! _Interfacesopt.equals(other.getInterfacesopt())) return false;
        if (! _ClassBody.equals(other.getClassBody())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getModifiersopt().hashCode());
        hash = hash * 31 + (getName().hashCode());
        hash = hash * 31 + (getSuperopt() == null ? 0 : getSuperopt().hashCode());
        hash = hash * 31 + (getInterfacesopt().hashCode());
        hash = hash * 31 + (getClassBody().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }

    private IToken docComment;
    public IToken getDocComment() { return docComment; }
        
    public void initialize()
    {
        docComment = environment.getDocComment(getLeftIToken());
    }
}


