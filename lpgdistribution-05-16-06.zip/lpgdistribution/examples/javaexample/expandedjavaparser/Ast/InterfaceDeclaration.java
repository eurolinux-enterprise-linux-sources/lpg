//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import expandedjavaparser.*;
import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 108:  InterfaceDeclaration ::= Modifiersopt interface IDENTIFIER$Name ExtendsInterfacesopt InterfaceBody
 *</b>
 */
public class InterfaceDeclaration extends Ast implements IInterfaceDeclaration
{
    private JavaParser environment;
    public JavaParser getEnvironment() { return environment; }

    private ModifierList _Modifiersopt;
    private AstToken _Name;
    private InterfaceTypeList _ExtendsInterfacesopt;
    private InterfaceBody _InterfaceBody;

    public ModifierList getModifiersopt() { return _Modifiersopt; }
    public AstToken getName() { return _Name; }
    public InterfaceTypeList getExtendsInterfacesopt() { return _ExtendsInterfacesopt; }
    public InterfaceBody getInterfaceBody() { return _InterfaceBody; }

    public InterfaceDeclaration(JavaParser environment, IToken leftIToken, IToken rightIToken,
                                ModifierList _Modifiersopt,
                                AstToken _Name,
                                InterfaceTypeList _ExtendsInterfacesopt,
                                InterfaceBody _InterfaceBody)
    {
        super(leftIToken, rightIToken);

        this.environment = environment;
        this._Modifiersopt = _Modifiersopt;
        this._Name = _Name;
        this._ExtendsInterfacesopt = _ExtendsInterfacesopt;
        this._InterfaceBody = _InterfaceBody;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof InterfaceDeclaration)) return false;
        InterfaceDeclaration other = (InterfaceDeclaration) o;
        if (! _Modifiersopt.equals(other.getModifiersopt())) return false;
        if (! _Name.equals(other.getName())) return false;
        if (! _ExtendsInterfacesopt.equals(other.getExtendsInterfacesopt())) return false;
        if (! _InterfaceBody.equals(other.getInterfaceBody())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getModifiersopt().hashCode());
        hash = hash * 31 + (getName().hashCode());
        hash = hash * 31 + (getExtendsInterfacesopt().hashCode());
        hash = hash * 31 + (getInterfaceBody().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }

    private IToken docComment;
    public IToken getDocComment() { return docComment; }
        
    public void initialize()
    {
        docComment = environment.getDocComment(getLeftIToken());
    }
}


