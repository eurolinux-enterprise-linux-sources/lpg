//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>PreDecrementExpression</b>
 */
public interface IPreDecrementExpression extends IStatementExpression, IUnaryExpression {}


