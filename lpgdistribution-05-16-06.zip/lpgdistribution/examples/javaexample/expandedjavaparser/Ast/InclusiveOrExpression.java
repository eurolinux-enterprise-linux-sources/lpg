//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<em>
 *<li>Rule 278:  InclusiveOrExpression ::= ExclusiveOrExpression
 *</em>
 *<p>
 *<b>
 *<li>Rule 279:  InclusiveOrExpression ::= InclusiveOrExpression | ExclusiveOrExpression
 *</b>
 */
public class InclusiveOrExpression extends Ast implements IInclusiveOrExpression
{
    private IInclusiveOrExpression _InclusiveOrExpression;
    private IExclusiveOrExpression _ExclusiveOrExpression;

    public IInclusiveOrExpression getInclusiveOrExpression() { return _InclusiveOrExpression; }
    public IExclusiveOrExpression getExclusiveOrExpression() { return _ExclusiveOrExpression; }

    public InclusiveOrExpression(IToken leftIToken, IToken rightIToken,
                                 IInclusiveOrExpression _InclusiveOrExpression,
                                 IExclusiveOrExpression _ExclusiveOrExpression)
    {
        super(leftIToken, rightIToken);

        this._InclusiveOrExpression = _InclusiveOrExpression;
        this._ExclusiveOrExpression = _ExclusiveOrExpression;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof InclusiveOrExpression)) return false;
        InclusiveOrExpression other = (InclusiveOrExpression) o;
        if (! _InclusiveOrExpression.equals(other.getInclusiveOrExpression())) return false;
        if (! _ExclusiveOrExpression.equals(other.getExclusiveOrExpression())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getInclusiveOrExpression().hashCode());
        hash = hash * 31 + (getExclusiveOrExpression().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


