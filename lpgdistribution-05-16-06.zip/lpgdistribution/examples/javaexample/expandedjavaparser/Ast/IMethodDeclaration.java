//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>MethodDeclaration</b>
 */
public interface IMethodDeclaration extends IClassMemberDeclaration {}


