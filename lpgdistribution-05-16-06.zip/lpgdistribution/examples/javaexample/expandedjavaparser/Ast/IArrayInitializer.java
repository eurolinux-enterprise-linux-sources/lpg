//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>ArrayInitializer</b>
 */
public interface IArrayInitializer extends IVariableInitializer {}


