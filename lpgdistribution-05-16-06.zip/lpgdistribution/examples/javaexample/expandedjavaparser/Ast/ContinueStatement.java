//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 189:  ContinueStatement ::= continue IDENTIFIERopt ;
 *</b>
 */
public class ContinueStatement extends Ast implements IContinueStatement
{
    private IDENTIFIERopt _IDENTIFIERopt;

    /**
     * The value returned by <b>getIDENTIFIERopt</b> may be <b>null</b>
     */
    public IDENTIFIERopt getIDENTIFIERopt() { return _IDENTIFIERopt; }

    public ContinueStatement(IToken leftIToken, IToken rightIToken,
                             IDENTIFIERopt _IDENTIFIERopt)
    {
        super(leftIToken, rightIToken);

        this._IDENTIFIERopt = _IDENTIFIERopt;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ContinueStatement)) return false;
        ContinueStatement other = (ContinueStatement) o;
        if (_IDENTIFIERopt == null && other.getIDENTIFIERopt() != null) return false;
        else if (! _IDENTIFIERopt.equals(other.getIDENTIFIERopt())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getIDENTIFIERopt() == null ? 0 : getIDENTIFIERopt().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


