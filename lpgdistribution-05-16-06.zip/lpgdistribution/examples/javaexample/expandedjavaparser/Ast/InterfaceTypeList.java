//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 63:  Interfaces ::= implements InterfaceTypeList
 *<li>Rule 64:  InterfaceTypeList ::= InterfaceType
 *<li>Rule 65:  InterfaceTypeList ::= InterfaceTypeList , InterfaceType
 *<li>Rule 109:  ExtendsInterfaces ::= extends InterfaceTypeList
 *<li>Rule 332:  Interfacesopt ::= $Empty
 *<li>Rule 333:  Interfacesopt ::= Interfaces
 *<li>Rule 340:  ExtendsInterfacesopt ::= $Empty
 *<li>Rule 341:  ExtendsInterfacesopt ::= ExtendsInterfaces
 *</b>
 */
public class InterfaceTypeList extends AstList implements IInterfaces, IInterfaceTypeList, IExtendsInterfaces, IInterfacesopt, IExtendsInterfacesopt
{
    public IInterfaceType getInterfaceTypeAt(int i) { return (IInterfaceType) getElementAt(i); }

    public InterfaceTypeList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public InterfaceTypeList(IInterfaceType _InterfaceType, boolean leftRecursive)
    {
        super((Ast) _InterfaceType, leftRecursive);
        initialize();
    }

    public void add(IInterfaceType _InterfaceType)
    {
        super.add((Ast) _InterfaceType);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof InterfaceTypeList)) return false;
        InterfaceTypeList other = (InterfaceTypeList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            IInterfaceType element = getInterfaceTypeAt(i);
            if (! element.equals(other.getInterfaceTypeAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getInterfaceTypeAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) getInterfaceTypeAt(i).accept(v); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getInterfaceTypeAt(i).accept(v, o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) getInterfaceTypeAt(i).accept(v); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getInterfaceTypeAt(i).accept(v, o); return null; }
}


