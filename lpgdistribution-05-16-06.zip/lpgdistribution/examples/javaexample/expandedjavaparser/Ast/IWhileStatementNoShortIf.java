//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>WhileStatement</b>
 */
public interface IWhileStatementNoShortIf extends IStatementNoShortIf {}


