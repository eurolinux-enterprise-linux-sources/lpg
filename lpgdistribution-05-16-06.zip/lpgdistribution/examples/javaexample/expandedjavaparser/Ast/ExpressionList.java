//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 214:  ArgumentList ::= Expression
 *<li>Rule 215:  ArgumentList ::= ArgumentList , Expression
 *<li>Rule 326:  ArgumentListopt ::= $Empty
 *<li>Rule 327:  ArgumentListopt ::= ArgumentList
 *</b>
 */
public class ExpressionList extends AstList implements IArgumentList, IArgumentListopt
{
    public IExpression getExpressionAt(int i) { return (IExpression) getElementAt(i); }

    public ExpressionList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public ExpressionList(IExpression _Expression, boolean leftRecursive)
    {
        super((Ast) _Expression, leftRecursive);
        initialize();
    }

    public void add(IExpression _Expression)
    {
        super.add((Ast) _Expression);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof ExpressionList)) return false;
        ExpressionList other = (ExpressionList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            IExpression element = getExpressionAt(i);
            if (! element.equals(other.getExpressionAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getExpressionAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) getExpressionAt(i).accept(v); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getExpressionAt(i).accept(v, o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) getExpressionAt(i).accept(v); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getExpressionAt(i).accept(v, o); return null; }
}


