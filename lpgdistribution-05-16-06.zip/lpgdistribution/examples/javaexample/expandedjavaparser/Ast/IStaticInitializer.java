//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>StaticInitializer</b>
 */
public interface IStaticInitializer extends IClassBodyDeclaration {}


