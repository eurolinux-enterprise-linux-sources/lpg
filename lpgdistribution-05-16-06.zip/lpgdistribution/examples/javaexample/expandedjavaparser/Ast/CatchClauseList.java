//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 195:  Catches ::= CatchClause
 *<li>Rule 196:  Catches ::= Catches CatchClause
 *<li>Rule 342:  Catchesopt ::= $Empty
 *<li>Rule 343:  Catchesopt ::= Catches
 *</b>
 */
public class CatchClauseList extends AstList implements ICatches, ICatchesopt
{
    public CatchClause getCatchClauseAt(int i) { return (CatchClause) getElementAt(i); }

    public CatchClauseList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public CatchClauseList(CatchClause _CatchClause, boolean leftRecursive)
    {
        super((Ast) _CatchClause, leftRecursive);
        initialize();
    }

    public void add(CatchClause _CatchClause)
    {
        super.add((Ast) _CatchClause);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof CatchClauseList)) return false;
        CatchClauseList other = (CatchClauseList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            CatchClause element = getCatchClauseAt(i);
            if (! element.equals(other.getCatchClauseAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getCatchClauseAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) v.visit(getCatchClauseAt(i)); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) v.visit(getCatchClauseAt(i), o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) v.visit(getCatchClauseAt(i)); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) v.visit(getCatchClauseAt(i), o); return null; }
}


