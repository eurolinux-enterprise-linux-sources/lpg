//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>ForStatement</b>
 */
public interface IForStatement extends IStatement {}


