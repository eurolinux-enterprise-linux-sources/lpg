//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 111:  InterfaceMemberDeclarations ::= InterfaceMemberDeclaration
 *<li>Rule 112:  InterfaceMemberDeclarations ::= InterfaceMemberDeclarations InterfaceMemberDeclaration
 *<li>Rule 334:  InterfaceMemberDeclarationsopt ::= $Empty
 *<li>Rule 335:  InterfaceMemberDeclarationsopt ::= InterfaceMemberDeclarations
 *</b>
 */
public class InterfaceMemberDeclarationList extends AstList implements IInterfaceMemberDeclarations, IInterfaceMemberDeclarationsopt
{
    public IInterfaceMemberDeclaration getInterfaceMemberDeclarationAt(int i) { return (IInterfaceMemberDeclaration) getElementAt(i); }

    public InterfaceMemberDeclarationList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public InterfaceMemberDeclarationList(IInterfaceMemberDeclaration _InterfaceMemberDeclaration, boolean leftRecursive)
    {
        super((Ast) _InterfaceMemberDeclaration, leftRecursive);
        initialize();
    }

    public void add(IInterfaceMemberDeclaration _InterfaceMemberDeclaration)
    {
        super.add((Ast) _InterfaceMemberDeclaration);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof InterfaceMemberDeclarationList)) return false;
        InterfaceMemberDeclarationList other = (InterfaceMemberDeclarationList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            IInterfaceMemberDeclaration element = getInterfaceMemberDeclarationAt(i);
            if (! element.equals(other.getInterfaceMemberDeclarationAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getInterfaceMemberDeclarationAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) getInterfaceMemberDeclarationAt(i).accept(v); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getInterfaceMemberDeclarationAt(i).accept(v, o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) getInterfaceMemberDeclarationAt(i).accept(v); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getInterfaceMemberDeclarationAt(i).accept(v, o); return null; }
}


