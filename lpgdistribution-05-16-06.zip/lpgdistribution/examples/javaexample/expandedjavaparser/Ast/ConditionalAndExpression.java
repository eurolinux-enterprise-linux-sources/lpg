//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<em>
 *<li>Rule 280:  ConditionalAndExpression ::= InclusiveOrExpression
 *</em>
 *<p>
 *<b>
 *<li>Rule 281:  ConditionalAndExpression ::= ConditionalAndExpression && InclusiveOrExpression
 *</b>
 */
public class ConditionalAndExpression extends Ast implements IConditionalAndExpression
{
    private IConditionalAndExpression _ConditionalAndExpression;
    private IInclusiveOrExpression _InclusiveOrExpression;

    public IConditionalAndExpression getConditionalAndExpression() { return _ConditionalAndExpression; }
    public IInclusiveOrExpression getInclusiveOrExpression() { return _InclusiveOrExpression; }

    public ConditionalAndExpression(IToken leftIToken, IToken rightIToken,
                                    IConditionalAndExpression _ConditionalAndExpression,
                                    IInclusiveOrExpression _InclusiveOrExpression)
    {
        super(leftIToken, rightIToken);

        this._ConditionalAndExpression = _ConditionalAndExpression;
        this._InclusiveOrExpression = _InclusiveOrExpression;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ConditionalAndExpression)) return false;
        ConditionalAndExpression other = (ConditionalAndExpression) o;
        if (! _ConditionalAndExpression.equals(other.getConditionalAndExpression())) return false;
        if (! _InclusiveOrExpression.equals(other.getInclusiveOrExpression())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getConditionalAndExpression().hashCode());
        hash = hash * 31 + (getInclusiveOrExpression().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


