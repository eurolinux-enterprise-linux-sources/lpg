//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 124:  BlockStatements ::= BlockStatement
 *<li>Rule 125:  BlockStatements ::= BlockStatements BlockStatement
 *<li>Rule 322:  BlockStatementsopt ::= $Empty
 *<li>Rule 323:  BlockStatementsopt ::= BlockStatements
 *</b>
 */
public class BlockStatementList extends AstList implements IBlockStatements, IBlockStatementsopt
{
    public IBlockStatement getBlockStatementAt(int i) { return (IBlockStatement) getElementAt(i); }

    public BlockStatementList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public BlockStatementList(IBlockStatement _BlockStatement, boolean leftRecursive)
    {
        super((Ast) _BlockStatement, leftRecursive);
        initialize();
    }

    public void add(IBlockStatement _BlockStatement)
    {
        super.add((Ast) _BlockStatement);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof BlockStatementList)) return false;
        BlockStatementList other = (BlockStatementList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            IBlockStatement element = getBlockStatementAt(i);
            if (! element.equals(other.getBlockStatementAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getBlockStatementAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) getBlockStatementAt(i).accept(v); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getBlockStatementAt(i).accept(v, o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) getBlockStatementAt(i).accept(v); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getBlockStatementAt(i).accept(v, o); return null; }
}


