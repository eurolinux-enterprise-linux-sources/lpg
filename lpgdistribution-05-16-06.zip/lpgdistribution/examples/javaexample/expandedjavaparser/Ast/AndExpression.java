//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<em>
 *<li>Rule 274:  AndExpression ::= EqualityExpression
 *</em>
 *<p>
 *<b>
 *<li>Rule 275:  AndExpression ::= AndExpression & EqualityExpression
 *</b>
 */
public class AndExpression extends Ast implements IAndExpression
{
    private IAndExpression _AndExpression;
    private IEqualityExpression _EqualityExpression;

    public IAndExpression getAndExpression() { return _AndExpression; }
    public IEqualityExpression getEqualityExpression() { return _EqualityExpression; }

    public AndExpression(IToken leftIToken, IToken rightIToken,
                         IAndExpression _AndExpression,
                         IEqualityExpression _EqualityExpression)
    {
        super(leftIToken, rightIToken);

        this._AndExpression = _AndExpression;
        this._EqualityExpression = _EqualityExpression;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof AndExpression)) return false;
        AndExpression other = (AndExpression) o;
        if (! _AndExpression.equals(other.getAndExpression())) return false;
        if (! _EqualityExpression.equals(other.getEqualityExpression())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getAndExpression().hashCode());
        hash = hash * 31 + (getEqualityExpression().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


