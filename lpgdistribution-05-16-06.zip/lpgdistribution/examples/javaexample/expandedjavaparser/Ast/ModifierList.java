//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 48:  Modifiers ::= Modifier
 *<li>Rule 49:  Modifiers ::= Modifiers Modifier
 *<li>Rule 320:  Modifiersopt ::= $Empty
 *<li>Rule 321:  Modifiersopt ::= Modifiers
 *</b>
 */
public class ModifierList extends AstList implements IModifiers, IModifiersopt
{
    public IModifier getModifierAt(int i) { return (IModifier) getElementAt(i); }

    public ModifierList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public ModifierList(IModifier _Modifier, boolean leftRecursive)
    {
        super((Ast) _Modifier, leftRecursive);
        initialize();
    }

    public void add(IModifier _Modifier)
    {
        super.add((Ast) _Modifier);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof ModifierList)) return false;
        ModifierList other = (ModifierList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            IModifier element = getModifierAt(i);
            if (! element.equals(other.getModifierAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getModifierAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) getModifierAt(i).accept(v); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getModifierAt(i).accept(v, o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) getModifierAt(i).accept(v); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) getModifierAt(i).accept(v, o); return null; }
}


