//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 193:  TryStatement ::= try Block Catches$Catchesopt
 *<li>Rule 194:  TryStatement ::= try Block Catchesopt Finally
 *</b>
 */
public class TryStatement extends Ast implements ITryStatement
{
    private Block _Block;
    private Ast _Catchesopt;
    private Finally _Finally;

    public Block getBlock() { return _Block; }
    public Ast getCatchesopt() { return _Catchesopt; }
    /**
     * The value returned by <b>getFinally</b> may be <b>null</b>
     */
    public Finally getFinally() { return _Finally; }

    public TryStatement(IToken leftIToken, IToken rightIToken,
                        Block _Block,
                        Ast _Catchesopt,
                        Finally _Finally)
    {
        super(leftIToken, rightIToken);

        this._Block = _Block;
        this._Catchesopt = _Catchesopt;
        this._Finally = _Finally;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof TryStatement)) return false;
        TryStatement other = (TryStatement) o;
        if (! _Block.equals(other.getBlock())) return false;
        if (! _Catchesopt.equals(other.getCatchesopt())) return false;
        if (_Finally == null && other.getFinally() != null) return false;
        else if (! _Finally.equals(other.getFinally())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getBlock().hashCode());
        hash = hash * 31 + (getCatchesopt().hashCode());
        hash = hash * 31 + (getFinally() == null ? 0 : getFinally().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


