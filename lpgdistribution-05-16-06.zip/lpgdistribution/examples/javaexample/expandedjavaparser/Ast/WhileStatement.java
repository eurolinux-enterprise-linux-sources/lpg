//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 178:  WhileStatement ::= while ( Expression ) Statement
 *<li>Rule 179:  WhileStatementNoShortIf ::= while ( Expression ) StatementNoShortIf$Statement
 *</b>
 */
public class WhileStatement extends Ast implements IWhileStatement, IWhileStatementNoShortIf
{
    private IExpression _Expression;
    private Ast _Statement;

    public IExpression getExpression() { return _Expression; }
    public Ast getStatement() { return _Statement; }

    public WhileStatement(IToken leftIToken, IToken rightIToken,
                          IExpression _Expression,
                          Ast _Statement)
    {
        super(leftIToken, rightIToken);

        this._Expression = _Expression;
        this._Statement = _Statement;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof WhileStatement)) return false;
        WhileStatement other = (WhileStatement) o;
        if (! _Expression.equals(other.getExpression())) return false;
        if (! _Statement.equals(other.getStatement())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getExpression().hashCode());
        hash = hash * 31 + (getStatement().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


