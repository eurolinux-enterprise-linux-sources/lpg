//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 90:  FormalParameterList ::= FormalParameter
 *<li>Rule 91:  FormalParameterList ::= FormalParameterList , FormalParameter
 *<li>Rule 330:  FormalParameterListopt ::= $Empty
 *<li>Rule 331:  FormalParameterListopt ::= FormalParameterList
 *</b>
 */
public class FormalParameterList extends AstList implements IFormalParameterList, IFormalParameterListopt
{
    public FormalParameter getFormalParameterAt(int i) { return (FormalParameter) getElementAt(i); }

    public FormalParameterList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public FormalParameterList(FormalParameter _FormalParameter, boolean leftRecursive)
    {
        super((Ast) _FormalParameter, leftRecursive);
        initialize();
    }

    public void add(FormalParameter _FormalParameter)
    {
        super.add((Ast) _FormalParameter);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof FormalParameterList)) return false;
        FormalParameterList other = (FormalParameterList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            FormalParameter element = getFormalParameterAt(i);
            if (! element.equals(other.getFormalParameterAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getFormalParameterAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) v.visit(getFormalParameterAt(i)); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) v.visit(getFormalParameterAt(i), o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) v.visit(getFormalParameterAt(i)); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) v.visit(getFormalParameterAt(i), o); return null; }
}


