//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>SingleTypeImportDeclaration</b>
 */
public interface ISingleTypeImportDeclaration extends IImportDeclaration {}


