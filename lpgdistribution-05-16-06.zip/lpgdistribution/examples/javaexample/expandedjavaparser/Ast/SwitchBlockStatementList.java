//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 171:  SwitchBlockStatements ::= SwitchBlockStatement
 *<li>Rule 172:  SwitchBlockStatements ::= SwitchBlockStatements SwitchBlockStatement
 *</b>
 */
public class SwitchBlockStatementList extends AstList implements ISwitchBlockStatements
{
    public SwitchBlockStatement getSwitchBlockStatementAt(int i) { return (SwitchBlockStatement) getElementAt(i); }

    public SwitchBlockStatementList(IToken leftIToken, IToken rightIToken, boolean leftRecursive)
    {
        super(leftIToken, rightIToken, leftRecursive);
        initialize();
    }

    public SwitchBlockStatementList(SwitchBlockStatement _SwitchBlockStatement, boolean leftRecursive)
    {
        super((Ast) _SwitchBlockStatement, leftRecursive);
        initialize();
    }

    public void add(SwitchBlockStatement _SwitchBlockStatement)
    {
        super.add((Ast) _SwitchBlockStatement);
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        if (! (o instanceof SwitchBlockStatementList)) return false;
        SwitchBlockStatementList other = (SwitchBlockStatementList) o;
        if (size() != other.size()) return false;
        for (int i = 0; i < size(); i++)
        {
            SwitchBlockStatement element = getSwitchBlockStatementAt(i);
            if (! element.equals(other.getSwitchBlockStatementAt(i))) return false;
        }
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        for (int i = 0; i < size(); i++)
            hash = hash * 31 + (getSwitchBlockStatementAt(i).hashCode());
        return hash;
    }

    public void accept(Visitor v) { for (int i = 0; i < size(); i++) v.visit(getSwitchBlockStatementAt(i)); }
    public void accept(ArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) v.visit(getSwitchBlockStatementAt(i), o); }
    public Object accept(ResultVisitor v) { for (int i = 0; i < size(); i++) v.visit(getSwitchBlockStatementAt(i)); return null; }
    public Object accept(ResultArgumentVisitor v, Object o) { for (int i = 0; i < size(); i++) v.visit(getSwitchBlockStatementAt(i), o); return null; }
}


