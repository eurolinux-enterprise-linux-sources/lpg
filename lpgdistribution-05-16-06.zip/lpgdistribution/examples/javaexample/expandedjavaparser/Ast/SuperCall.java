//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 105:  ExplicitConstructorInvocation ::= super ( ArgumentListopt ) ;
 *<li>Rule 106:  ExplicitConstructorInvocation ::= Primary$expression . super ( ArgumentListopt ) ;
 *<li>Rule 107:  ExplicitConstructorInvocation ::= Name$expression . super ( ArgumentListopt ) ;
 *</b>
 */
public class SuperCall extends Ast implements IExplicitConstructorInvocation
{
    private ExpressionList _ArgumentListopt;
    private IPostfixExpression _expression;

    public ExpressionList getArgumentListopt() { return _ArgumentListopt; }
    /**
     * The value returned by <b>getexpression</b> may be <b>null</b>
     */
    public IPostfixExpression getexpression() { return _expression; }

    public SuperCall(IToken leftIToken, IToken rightIToken,
                     ExpressionList _ArgumentListopt,
                     IPostfixExpression _expression)
    {
        super(leftIToken, rightIToken);

        this._ArgumentListopt = _ArgumentListopt;
        this._expression = _expression;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof SuperCall)) return false;
        SuperCall other = (SuperCall) o;
        if (! _ArgumentListopt.equals(other.getArgumentListopt())) return false;
        if (_expression == null && other.getexpression() != null) return false;
        else if (! _expression.equals(other.getexpression())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getArgumentListopt().hashCode());
        hash = hash * 31 + (getexpression() == null ? 0 : getexpression().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


