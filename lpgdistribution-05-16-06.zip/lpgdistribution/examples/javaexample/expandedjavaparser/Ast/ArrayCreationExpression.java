//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 216:  ArrayCreationExpression ::= new PrimitiveType$Type DimExprs Dimsopt
 *<li>Rule 217:  ArrayCreationExpression ::= new ClassOrInterfaceType$Type DimExprs Dimsopt
 *<li>Rule 218:  ArrayCreationExpression ::= new ArrayType$Type ArrayInitializer
 *</b>
 */
public class ArrayCreationExpression extends Ast implements IArrayCreationExpression
{
    private IType _Type;
    private DimExprList _DimExprs;
    private DimList _Dimsopt;
    private ArrayInitializer _ArrayInitializer;

    public IType getType() { return _Type; }
    /**
     * The value returned by <b>getDimExprs</b> may be <b>null</b>
     */
    public DimExprList getDimExprs() { return _DimExprs; }
    /**
     * The value returned by <b>getDimsopt</b> may be <b>null</b>
     */
    public DimList getDimsopt() { return _Dimsopt; }
    /**
     * The value returned by <b>getArrayInitializer</b> may be <b>null</b>
     */
    public ArrayInitializer getArrayInitializer() { return _ArrayInitializer; }

    public ArrayCreationExpression(IToken leftIToken, IToken rightIToken,
                                   IType _Type,
                                   DimExprList _DimExprs,
                                   DimList _Dimsopt,
                                   ArrayInitializer _ArrayInitializer)
    {
        super(leftIToken, rightIToken);

        this._Type = _Type;
        this._DimExprs = _DimExprs;
        this._Dimsopt = _Dimsopt;
        this._ArrayInitializer = _ArrayInitializer;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof ArrayCreationExpression)) return false;
        ArrayCreationExpression other = (ArrayCreationExpression) o;
        if (! _Type.equals(other.getType())) return false;
        if (_DimExprs == null && other.getDimExprs() != null) return false;
        else if (! _DimExprs.equals(other.getDimExprs())) return false;
        if (_Dimsopt == null && other.getDimsopt() != null) return false;
        else if (! _Dimsopt.equals(other.getDimsopt())) return false;
        if (_ArrayInitializer == null && other.getArrayInitializer() != null) return false;
        else if (! _ArrayInitializer.equals(other.getArrayInitializer())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getType().hashCode());
        hash = hash * 31 + (getDimExprs() == null ? 0 : getDimExprs().hashCode());
        hash = hash * 31 + (getDimsopt() == null ? 0 : getDimsopt().hashCode());
        hash = hash * 31 + (getArrayInitializer() == null ? 0 : getArrayInitializer().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


