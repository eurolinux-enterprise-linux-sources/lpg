//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 260:  AdditiveExpression ::= AdditiveExpression - MultiplicativeExpression
 *</b>
 */
public class SubtractExpression extends Ast implements IAdditiveExpression
{
    private IAdditiveExpression _AdditiveExpression;
    private IMultiplicativeExpression _MultiplicativeExpression;

    public IAdditiveExpression getAdditiveExpression() { return _AdditiveExpression; }
    public IMultiplicativeExpression getMultiplicativeExpression() { return _MultiplicativeExpression; }

    public SubtractExpression(IToken leftIToken, IToken rightIToken,
                              IAdditiveExpression _AdditiveExpression,
                              IMultiplicativeExpression _MultiplicativeExpression)
    {
        super(leftIToken, rightIToken);

        this._AdditiveExpression = _AdditiveExpression;
        this._MultiplicativeExpression = _MultiplicativeExpression;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof SubtractExpression)) return false;
        SubtractExpression other = (SubtractExpression) o;
        if (! _AdditiveExpression.equals(other.getAdditiveExpression())) return false;
        if (! _MultiplicativeExpression.equals(other.getMultiplicativeExpression())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getAdditiveExpression().hashCode());
        hash = hash * 31 + (getMultiplicativeExpression().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


