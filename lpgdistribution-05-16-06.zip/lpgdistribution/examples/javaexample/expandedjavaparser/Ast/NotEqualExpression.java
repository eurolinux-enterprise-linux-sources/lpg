//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 273:  EqualityExpression ::= EqualityExpression != RelationalExpression
 *</b>
 */
public class NotEqualExpression extends Ast implements IEqualityExpression
{
    private IEqualityExpression _EqualityExpression;
    private IRelationalExpression _RelationalExpression;

    public IEqualityExpression getEqualityExpression() { return _EqualityExpression; }
    public IRelationalExpression getRelationalExpression() { return _RelationalExpression; }

    public NotEqualExpression(IToken leftIToken, IToken rightIToken,
                              IEqualityExpression _EqualityExpression,
                              IRelationalExpression _RelationalExpression)
    {
        super(leftIToken, rightIToken);

        this._EqualityExpression = _EqualityExpression;
        this._RelationalExpression = _RelationalExpression;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof NotEqualExpression)) return false;
        NotEqualExpression other = (NotEqualExpression) o;
        if (! _EqualityExpression.equals(other.getEqualityExpression())) return false;
        if (! _RelationalExpression.equals(other.getRelationalExpression())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getEqualityExpression().hashCode());
        hash = hash * 31 + (getRelationalExpression().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


