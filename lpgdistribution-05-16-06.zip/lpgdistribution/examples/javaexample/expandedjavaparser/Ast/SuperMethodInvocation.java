//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

import lpg.lpgjavaruntime.*;

/**
 *<b>
 *<li>Rule 230:  MethodInvocation ::= super . IDENTIFIER ( ArgumentListopt )
 *<li>Rule 231:  MethodInvocation ::= Name . super . IDENTIFIER ( ArgumentListopt )
 *</b>
 */
public class SuperMethodInvocation extends Ast implements IMethodInvocation
{
    private ExpressionList _ArgumentListopt;
    private IName _Name;

    public ExpressionList getArgumentListopt() { return _ArgumentListopt; }
    /**
     * The value returned by <b>getName</b> may be <b>null</b>
     */
    public IName getName() { return _Name; }

    public SuperMethodInvocation(IToken leftIToken, IToken rightIToken,
                                 ExpressionList _ArgumentListopt,
                                 IName _Name)
    {
        super(leftIToken, rightIToken);

        this._ArgumentListopt = _ArgumentListopt;
        this._Name = _Name;
        initialize();
    }

    public boolean equals(Object o)
    {
        if (o == this) return true;
        //
        // The supers call is not required for now because Ast nodes
        // can only extend the root Ast, AstToken and AstList and none
        // of these nodes contain children.
        //
        // if (! super.equals(o)) return false;
        //
        if (! (o instanceof SuperMethodInvocation)) return false;
        SuperMethodInvocation other = (SuperMethodInvocation) o;
        if (! _ArgumentListopt.equals(other.getArgumentListopt())) return false;
        if (_Name == null && other.getName() != null) return false;
        else if (! _Name.equals(other.getName())) return false;
        return true;
    }

    public int hashCode()
    {
        int hash = 7;
        hash = hash * 31 + (getArgumentListopt().hashCode());
        hash = hash * 31 + (getName() == null ? 0 : getName().hashCode());
        return hash;
    }

    public void accept(Visitor v) { v.visit(this); }
    public void accept(ArgumentVisitor v, Object o) { v.visit(this, o); }
    public Object accept(ResultVisitor v) { return v.visit(this); }
    public Object accept(ResultArgumentVisitor v, Object o) { return v.visit(this, o); }
}


