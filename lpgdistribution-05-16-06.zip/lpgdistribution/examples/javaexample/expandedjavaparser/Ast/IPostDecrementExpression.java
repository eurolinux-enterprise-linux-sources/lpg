//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser.Ast;

/**
 * is implemented by <b>PostDecrementExpression</b>
 */
public interface IPostDecrementExpression extends IStatementExpression, IPostfixExpression {}


