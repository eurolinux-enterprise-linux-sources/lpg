//
// A copyright notice must contain a "C" enclosed in parentheses: (C) 
//

package expandedjavaparser;

import expandedjavaparser.Ast.*;
import lpg.lpgjavaruntime.*;

public class JavaParser extends PrsStream implements RuleAction
{
    private static ParseTable prs = new JavaParserprs();
    private DeterministicParser dtParser;

    public DeterministicParser getParser() { return dtParser; }
    private void setResult(Object object) { dtParser.setSym1(object); }
    public Object getRhsSym(int i) { return dtParser.getSym(i); }

    public int getRhsTokenIndex(int i) { return dtParser.getToken(i); }
    public IToken getRhsIToken(int i) { return super.getIToken(getRhsTokenIndex(i)); }
    
    public int getRhsFirstTokenIndex(int i) { return dtParser.getFirstToken(i); }
    public IToken getRhsFirstIToken(int i) { return super.getIToken(getRhsFirstTokenIndex(i)); }

    public int getRhsLastTokenIndex(int i) { return dtParser.getLastToken(i); }
    public IToken getRhsLastIToken(int i) { return super.getIToken(getRhsLastTokenIndex(i)); }

    public int getLeftSpan() { return dtParser.getFirstToken(); }
    public IToken getLeftIToken()  { return super.getIToken(getLeftSpan()); }

    public int getRightSpan() { return dtParser.getLastToken(); }
    public IToken getRightIToken() { return super.getIToken(getRightSpan()); }

    public int getRhsErrorTokenIndex(int i)
    {
        int index = dtParser.getToken(i);
        IToken err = super.getIToken(index);
        return (err instanceof ErrorToken ? index : 0);
    }
    public ErrorToken getRhsErrorIToken(int i)
    {
        int index = dtParser.getToken(i);
        IToken err = super.getIToken(index);
        return (ErrorToken) (err instanceof ErrorToken ? err : null);
    }

    public JavaParser(LexStream lexStream)
    {
        super(lexStream);

        try
        {
            super.remapTerminalSymbols(orderedTerminalSymbols(), JavaParserprs.EOFT_SYMBOL);
        }
        catch(NullExportedSymbolsException e) {
        }
        catch(NullTerminalSymbolsException e) {
        }
        catch(UnimplementedTerminalsException e)
        {
            java.util.ArrayList unimplemented_symbols = e.getSymbols();
            System.out.println("The Lexer will not scan the following token(s):");
            for (int i = 0; i < unimplemented_symbols.size(); i++)
            {
                Integer id = (Integer) unimplemented_symbols.get(i);
                System.out.println("    " + JavaParsersym.orderedTerminalSymbols[id.intValue()]);               
            }
            System.out.println();                        
        }
        catch(UndefinedEofSymbolException e)
        {
            throw new Error(new UndefinedEofSymbolException
                                ("The Lexer does not implement the Eof symbol " +
                                 JavaParsersym.orderedTerminalSymbols[JavaParserprs.EOFT_SYMBOL]));
        } 
    }

    public String[] orderedTerminalSymbols() { return JavaParsersym.orderedTerminalSymbols; }
    public String getTokenKindName(int kind) { return JavaParsersym.orderedTerminalSymbols[kind]; }            
    public int getEOFTokenKind() { return JavaParserprs.EOFT_SYMBOL; }
    public PrsStream getParseStream() { return (PrsStream) this; }

    public Ast parser()
    {
        return parser(null, 0);
    }
        
    public Ast parser(Monitor monitor)
    {
        return parser(monitor, 0);
    }
        
    public Ast parser(int error_repair_count)
    {
        return parser(null, error_repair_count);
    }
        
    public Ast parser(Monitor monitor, int error_repair_count)
    {
        try
        {
            dtParser = new DeterministicParser(monitor, (TokenStream)this, prs, (RuleAction)this);
        }
        catch (NotDeterministicParseTableException e)
        {
            throw new Error(new NotDeterministicParseTableException
                                ("Regenerate JavaParserprs.java with -NOBACKTRACK option"));
        }
        catch (BadParseSymFileException e)
        {
            throw new Error(new BadParseSymFileException("Bad Parser Symbol File -- JavaParsersym.java. Regenerate JavaParserprs.java"));
        }

        try
        {
            return (Ast) dtParser.parse();
        }
        catch (BadParseException e)
        {
            reset(e.error_token); // point to error token

            DiagnoseParser diagnoseParser = new DiagnoseParser(this, prs);
            diagnoseParser.diagnose(e.error_token);
        }

        return null;
    }


    public IToken getPrevious(IToken tok)
    {
        return getIToken(getPrevious(tok.getTokenIndex()));
    }
    
    public IToken getDocComment(IToken token)
    {
        int token_index = token.getTokenIndex();
        IToken[] adjuncts = getPrecedingAdjuncts(token_index);
        int i = adjuncts.length - 1;
        IToken comment = (i >= 0 && adjuncts[i].getKind() == JavaParsersym.TK_DocComment
                                  ? adjuncts[i]
                                  : null);
        return comment;
    }
    

    public void ruleAction(int ruleNumber)
    {
        switch (ruleNumber)
        {
 
            //
            // Rule 1:  Literal ::= IntegerLiteral
            //
            case 1: {
                setResult(
                    new IntegerLiteral(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 2:  Literal ::= LongLiteral
            //
            case 2: {
                setResult(
                    new LongLiteral(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 3:  Literal ::= FloatingPointLiteral
            //
            case 3: {
                setResult(
                    new FloatLiteral(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 4:  Literal ::= DoubleLiteral
            //
            case 4: {
                setResult(
                    new DoubleLiteral(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 5:  Literal ::= BooleanLiteral
            //
            case 5: {
                setResult(
                    new BooleanLiteral(getLeftIToken(), getRightIToken(),
                                       (IBooleanLiteral)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 6:  Literal ::= CharacterLiteral
            //
            case 6: {
                setResult(
                    new CharacterLiteral(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 7:  Literal ::= StringLiteral
            //
            case 7: {
                setResult(
                    new StringLiteral(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 8:  Literal ::= null
            //
            case 8: {
                setResult(
                    new NullLiteral(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 9:  BooleanLiteral ::= true
            //
            case 9: {
                setResult(
                    new TrueLiteral(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 10:  BooleanLiteral ::= false
            //
            case 10: {
                setResult(
                    new FalseLiteral(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 11:  Type ::= PrimitiveType
            //
            case 11:
                break; 
            //
            // Rule 12:  Type ::= ReferenceType
            //
            case 12:
                break; 
            //
            // Rule 13:  PrimitiveType ::= NumericType
            //
            case 13:
                break; 
            //
            // Rule 14:  PrimitiveType ::= boolean
            //
            case 14: {
                setResult(
                    new BooleanType(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 15:  NumericType ::= IntegralType
            //
            case 15:
                break; 
            //
            // Rule 16:  NumericType ::= FloatingPointType
            //
            case 16:
                break; 
            //
            // Rule 17:  IntegralType ::= byte
            //
            case 17: {
                setResult(
                    new ByteType(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 18:  IntegralType ::= short
            //
            case 18: {
                setResult(
                    new ShortType(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 19:  IntegralType ::= int
            //
            case 19: {
                setResult(
                    new IntType(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 20:  IntegralType ::= long
            //
            case 20: {
                setResult(
                    new LongType(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 21:  IntegralType ::= char
            //
            case 21: {
                setResult(
                    new CharType(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 22:  FloatingPointType ::= float
            //
            case 22: {
                setResult(
                    new FloatType(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 23:  FloatingPointType ::= double
            //
            case 23: {
                setResult(
                    new DoubleType(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 24:  ReferenceType ::= ClassOrInterfaceType
            //
            case 24:
                break; 
            //
            // Rule 25:  ReferenceType ::= ArrayType
            //
            case 25:
                break; 
            //
            // Rule 26:  ClassOrInterfaceType ::= Name
            //
            case 26:
                break; 
            //
            // Rule 27:  ArrayType ::= PrimitiveType Dims
            //
            case 27: {
                setResult(
                    new PrimitiveArrayType(getLeftIToken(), getRightIToken(),
                                           (IPrimitiveType)getRhsSym(1),
                                           (DimList)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 28:  ArrayType ::= Name Dims
            //
            case 28: {
                setResult(
                    new ClassOrInterfaceArrayType(getLeftIToken(), getRightIToken(),
                                                  (IName)getRhsSym(1),
                                                  (DimList)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 29:  ClassType ::= ClassOrInterfaceType
            //
            case 29:
                break; 
            //
            // Rule 30:  InterfaceType ::= ClassOrInterfaceType
            //
            case 30:
                break; 
            //
            // Rule 31:  Name ::= SimpleName
            //
            case 31:
                break; 
            //
            // Rule 32:  Name ::= QualifiedName
            //
            case 32:
                break; 
            //
            // Rule 33:  SimpleName ::= IDENTIFIER
            //
            case 33: {
                setResult(
                    new SimpleName(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 34:  QualifiedName ::= Name . IDENTIFIER
            //
            case 34: {
                setResult(
                    new QualifiedName(getLeftIToken(), getRightIToken(),
                                      (IName)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 35:  CompilationUnit ::= PackageDeclarationopt ImportDeclarationsopt TypeDeclarationsopt
            //
            case 35: {
                setResult(
                    new CompilationUnit(getLeftIToken(), getRightIToken(),
                                        (PackageDeclaration)getRhsSym(1),
                                        (ImportDeclarationList)getRhsSym(2),
                                        (TypeDeclarationList)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 36:  ImportDeclarations ::= ImportDeclaration
            //
            case 36: {
                setResult(
                    new ImportDeclarationList((IImportDeclaration)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 37:  ImportDeclarations ::= ImportDeclarations ImportDeclaration
            //
            case 37: {
                ((ImportDeclarationList)getRhsSym(1)).add((IImportDeclaration)getRhsSym(2));
                break;
            } 
            //
            // Rule 38:  TypeDeclarations ::= TypeDeclaration
            //
            case 38: {
                setResult(
                    new TypeDeclarationList((ITypeDeclaration)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 39:  TypeDeclarations ::= TypeDeclarations TypeDeclaration
            //
            case 39: {
                ((TypeDeclarationList)getRhsSym(1)).add((ITypeDeclaration)getRhsSym(2));
                break;
            } 
            //
            // Rule 40:  PackageDeclaration ::= package Name ;
            //
            case 40: {
                setResult(
                    new PackageDeclaration(getLeftIToken(), getRightIToken(),
                                           (IName)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 41:  ImportDeclaration ::= SingleTypeImportDeclaration
            //
            case 41:
                break; 
            //
            // Rule 42:  ImportDeclaration ::= TypeImportOnDemandDeclaration
            //
            case 42:
                break; 
            //
            // Rule 43:  SingleTypeImportDeclaration ::= import Name ;
            //
            case 43: {
                setResult(
                    new SingleTypeImportDeclaration(getLeftIToken(), getRightIToken(),
                                                    (IName)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 44:  TypeImportOnDemandDeclaration ::= import Name . * ;
            //
            case 44: {
                setResult(
                    new TypeImportOnDemandDeclaration(getLeftIToken(), getRightIToken(),
                                                      (IName)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 45:  TypeDeclaration ::= ClassDeclaration
            //
            case 45:
                break; 
            //
            // Rule 46:  TypeDeclaration ::= InterfaceDeclaration
            //
            case 46:
                break; 
            //
            // Rule 47:  TypeDeclaration ::= ;
            //
            case 47: {
                setResult(
                    new EmptyDeclaration(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 48:  Modifiers ::= Modifier
            //
            case 48: {
                setResult(
                    new ModifierList((IModifier)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 49:  Modifiers ::= Modifiers Modifier
            //
            case 49: {
                ((ModifierList)getRhsSym(1)).add((IModifier)getRhsSym(2));
                break;
            } 
            //
            // Rule 50:  Modifier ::= public
            //
            case 50: {
                setResult(
                    new PublicModifier(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 51:  Modifier ::= protected
            //
            case 51: {
                setResult(
                    new ProtectedModifier(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 52:  Modifier ::= private
            //
            case 52: {
                setResult(
                    new PrivateModifier(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 53:  Modifier ::= static
            //
            case 53: {
                setResult(
                    new StaticModifier(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 54:  Modifier ::= abstract
            //
            case 54: {
                setResult(
                    new AbstractModifier(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 55:  Modifier ::= final
            //
            case 55: {
                setResult(
                    new FinalModifier(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 56:  Modifier ::= native
            //
            case 56: {
                setResult(
                    new NativeModifier(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 57:  Modifier ::= strictfp
            //
            case 57: {
                setResult(
                    new StrictfpModifier(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 58:  Modifier ::= synchronized
            //
            case 58: {
                setResult(
                    new SynchronizedModifier(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 59:  Modifier ::= transient
            //
            case 59: {
                setResult(
                    new TransientModifier(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 60:  Modifier ::= volatile
            //
            case 60: {
                setResult(
                    new VolatileModifier(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 61:  ClassDeclaration ::= Modifiersopt class IDENTIFIER$Name Superopt Interfacesopt ClassBody
            //
            case 61: {
                setResult(
                    new ClassDeclaration(JavaParser.this, getLeftIToken(), getRightIToken(),
                                         (ModifierList)getRhsSym(1),
                                         new AstToken(getRhsIToken(3)),
                                         (Super)getRhsSym(4),
                                         (InterfaceTypeList)getRhsSym(5),
                                         (ClassBody)getRhsSym(6))
                );
                break;
            } 
            //
            // Rule 62:  Super ::= extends ClassType
            //
            case 62: {
                setResult(
                    new Super(getLeftIToken(), getRightIToken(),
                              (IClassType)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 63:  Interfaces ::= implements InterfaceTypeList
            //
            case 63: {
                setResult((InterfaceTypeList)getRhsSym(2));
                break;
            } 
            //
            // Rule 64:  InterfaceTypeList ::= InterfaceType
            //
            case 64: {
                setResult(
                    new InterfaceTypeList((IInterfaceType)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 65:  InterfaceTypeList ::= InterfaceTypeList , InterfaceType
            //
            case 65: {
                ((InterfaceTypeList)getRhsSym(1)).add((IInterfaceType)getRhsSym(3));
                break;
            } 
            //
            // Rule 66:  ClassBody ::= { ClassBodyDeclarationsopt }
            //
            case 66: {
                setResult(
                    new ClassBody(getLeftIToken(), getRightIToken(),
                                  (ClassBodyDeclarationList)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 67:  ClassBodyDeclarations ::= ClassBodyDeclaration
            //
            case 67: {
                setResult(
                    new ClassBodyDeclarationList((IClassBodyDeclaration)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 68:  ClassBodyDeclarations ::= ClassBodyDeclarations ClassBodyDeclaration
            //
            case 68: {
                ((ClassBodyDeclarationList)getRhsSym(1)).add((IClassBodyDeclaration)getRhsSym(2));
                break;
            } 
            //
            // Rule 69:  ClassBodyDeclaration ::= ClassMemberDeclaration
            //
            case 69:
                break; 
            //
            // Rule 70:  ClassBodyDeclaration ::= StaticInitializer
            //
            case 70:
                break; 
            //
            // Rule 71:  ClassBodyDeclaration ::= ConstructorDeclaration
            //
            case 71:
                break; 
            //
            // Rule 72:  ClassBodyDeclaration ::= Block
            //
            case 72:
                break; 
            //
            // Rule 73:  ClassMemberDeclaration ::= FieldDeclaration
            //
            case 73:
                break; 
            //
            // Rule 74:  ClassMemberDeclaration ::= MethodDeclaration
            //
            case 74:
                break; 
            //
            // Rule 75:  ClassMemberDeclaration ::= ClassDeclaration
            //
            case 75:
                break; 
            //
            // Rule 76:  ClassMemberDeclaration ::= InterfaceDeclaration
            //
            case 76:
                break; 
            //
            // Rule 77:  ClassMemberDeclaration ::= ;
            //
            case 77: {
                setResult(
                    new EmptyDeclaration(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 78:  FieldDeclaration ::= Modifiersopt Type VariableDeclarators ;
            //
            case 78: {
                setResult(
                    new FieldDeclaration(JavaParser.this, getLeftIToken(), getRightIToken(),
                                         (ModifierList)getRhsSym(1),
                                         (IType)getRhsSym(2),
                                         (VariableDeclaratorList)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 79:  VariableDeclarators ::= VariableDeclarator
            //
            case 79: {
                setResult(
                    new VariableDeclaratorList((IVariableDeclarator)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 80:  VariableDeclarators ::= VariableDeclarators , VariableDeclarator
            //
            case 80: {
                ((VariableDeclaratorList)getRhsSym(1)).add((IVariableDeclarator)getRhsSym(3));
                break;
            } 
            //
            // Rule 81:  VariableDeclarator ::= VariableDeclaratorId
            //
            case 81:
                break; 
            //
            // Rule 82:  VariableDeclarator ::= VariableDeclaratorId = VariableInitializer
            //
            case 82: {
                setResult(
                    new VariableDeclarator(getLeftIToken(), getRightIToken(),
                                           (VariableDeclaratorId)getRhsSym(1),
                                           (IVariableInitializer)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 83:  VariableDeclaratorId ::= IDENTIFIER Dimsopt
            //
            case 83: {
                setResult(
                    new VariableDeclaratorId(getLeftIToken(), getRightIToken(),
                                             (DimList)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 84:  VariableInitializer ::= Expression
            //
            case 84:
                break; 
            //
            // Rule 85:  VariableInitializer ::= ArrayInitializer
            //
            case 85:
                break; 
            //
            // Rule 86:  MethodDeclaration ::= MethodHeader MethodBody
            //
            case 86: {
                setResult(
                    new MethodDeclaration(JavaParser.this, getLeftIToken(), getRightIToken(),
                                          (IMethodHeader)getRhsSym(1),
                                          (IMethodBody)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 87:  MethodHeader ::= Modifiersopt Type MethodDeclarator Throwsopt
            //
            case 87: {
                setResult(
                    new TypedMethodHeader(getLeftIToken(), getRightIToken(),
                                          (ModifierList)getRhsSym(1),
                                          (IType)getRhsSym(2),
                                          (MethodDeclarator)getRhsSym(3),
                                          (ClassTypeList)getRhsSym(4))
                );
                break;
            } 
            //
            // Rule 88:  MethodHeader ::= Modifiersopt void MethodDeclarator Throwsopt
            //
            case 88: {
                setResult(
                    new VoidMethodHeader(getLeftIToken(), getRightIToken(),
                                         (ModifierList)getRhsSym(1),
                                         (MethodDeclarator)getRhsSym(3),
                                         (ClassTypeList)getRhsSym(4))
                );
                break;
            } 
            //
            // Rule 89:  MethodDeclarator ::= IDENTIFIER ( FormalParameterListopt ) Dimsopt
            //
            case 89: {
                setResult(
                    new MethodDeclarator(getLeftIToken(), getRightIToken(),
                                         (FormalParameterList)getRhsSym(3),
                                         (DimList)getRhsSym(5))
                );
                break;
            } 
            //
            // Rule 90:  FormalParameterList ::= FormalParameter
            //
            case 90: {
                setResult(
                    new FormalParameterList((FormalParameter)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 91:  FormalParameterList ::= FormalParameterList , FormalParameter
            //
            case 91: {
                ((FormalParameterList)getRhsSym(1)).add((FormalParameter)getRhsSym(3));
                break;
            } 
            //
            // Rule 92:  FormalParameter ::= Modifiersopt Type VariableDeclaratorId
            //
            case 92: {
                setResult(
                    new FormalParameter(getLeftIToken(), getRightIToken(),
                                        (ModifierList)getRhsSym(1),
                                        (IType)getRhsSym(2),
                                        (VariableDeclaratorId)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 93:  Throws ::= throws ClassTypeList
            //
            case 93: {
                setResult((ClassTypeList)getRhsSym(2));
                break;
            } 
            //
            // Rule 94:  ClassTypeList ::= ClassType
            //
            case 94: {
                setResult(
                    new ClassTypeList((IClassType)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 95:  ClassTypeList ::= ClassTypeList , ClassType
            //
            case 95: {
                ((ClassTypeList)getRhsSym(1)).add((IClassType)getRhsSym(3));
                break;
            } 
            //
            // Rule 96:  MethodBody ::= Block
            //
            case 96:
                break; 
            //
            // Rule 97:  MethodBody ::= ;
            //
            case 97: {
                setResult(
                    new EmptyMethodBody(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 98:  StaticInitializer ::= static Block
            //
            case 98: {
                setResult(
                    new StaticInitializer(getLeftIToken(), getRightIToken(),
                                          (Block)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 99:  ConstructorDeclaration ::= Modifiersopt ConstructorDeclarator Throwsopt ConstructorBody
            //
            case 99: {
                setResult(
                    new ConstructorDeclaration(JavaParser.this, getLeftIToken(), getRightIToken(),
                                               (ModifierList)getRhsSym(1),
                                               (ConstructorDeclarator)getRhsSym(2),
                                               (ClassTypeList)getRhsSym(3),
                                               (IConstructorBody)getRhsSym(4))
                );
                break;
            } 
            //
            // Rule 100:  ConstructorDeclarator ::= IDENTIFIER ( FormalParameterListopt )
            //
            case 100: {
                setResult(
                    new ConstructorDeclarator(getLeftIToken(), getRightIToken(),
                                              (FormalParameterList)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 101:  ConstructorBody ::= Block
            //
            case 101:
                break; 
            //
            // Rule 102:  ConstructorBody ::= { ExplicitConstructorInvocation BlockStatementsopt }
            //
            case 102: {
                setResult(
                    new ConstructorBody(getLeftIToken(), getRightIToken(),
                                        (IExplicitConstructorInvocation)getRhsSym(2),
                                        (BlockStatementList)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 103:  ExplicitConstructorInvocation ::= this ( ArgumentListopt ) ;
            //
            case 103: {
                setResult(
                    new ThisCall(getLeftIToken(), getRightIToken(),
                                 (ExpressionList)getRhsSym(3),
                                 (IPrimary)null)
                );
                break;
            } 
            //
            // Rule 104:  ExplicitConstructorInvocation ::= Primary . this ( ArgumentListopt ) ;
            //
            case 104: {
                setResult(
                    new ThisCall(getLeftIToken(), getRightIToken(),
                                 (ExpressionList)getRhsSym(5),
                                 (IPrimary)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 105:  ExplicitConstructorInvocation ::= super ( ArgumentListopt ) ;
            //
            case 105: {
                setResult(
                    new SuperCall(getLeftIToken(), getRightIToken(),
                                  (ExpressionList)getRhsSym(3),
                                  (IPostfixExpression)null)
                );
                break;
            } 
            //
            // Rule 106:  ExplicitConstructorInvocation ::= Primary$expression . super ( ArgumentListopt ) ;
            //
            case 106: {
                setResult(
                    new SuperCall(getLeftIToken(), getRightIToken(),
                                  (ExpressionList)getRhsSym(5),
                                  (IPostfixExpression)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 107:  ExplicitConstructorInvocation ::= Name$expression . super ( ArgumentListopt ) ;
            //
            case 107: {
                setResult(
                    new SuperCall(getLeftIToken(), getRightIToken(),
                                  (ExpressionList)getRhsSym(5),
                                  (IPostfixExpression)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 108:  InterfaceDeclaration ::= Modifiersopt interface IDENTIFIER$Name ExtendsInterfacesopt InterfaceBody
            //
            case 108: {
                setResult(
                    new InterfaceDeclaration(JavaParser.this, getLeftIToken(), getRightIToken(),
                                             (ModifierList)getRhsSym(1),
                                             new AstToken(getRhsIToken(3)),
                                             (InterfaceTypeList)getRhsSym(4),
                                             (InterfaceBody)getRhsSym(5))
                );
                break;
            } 
            //
            // Rule 109:  ExtendsInterfaces ::= extends InterfaceTypeList
            //
            case 109: {
                setResult((InterfaceTypeList)getRhsSym(2));
                break;
            } 
            //
            // Rule 110:  InterfaceBody ::= { InterfaceMemberDeclarationsopt }
            //
            case 110: {
                setResult(
                    new InterfaceBody(getLeftIToken(), getRightIToken(),
                                      (InterfaceMemberDeclarationList)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 111:  InterfaceMemberDeclarations ::= InterfaceMemberDeclaration
            //
            case 111: {
                setResult(
                    new InterfaceMemberDeclarationList((IInterfaceMemberDeclaration)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 112:  InterfaceMemberDeclarations ::= InterfaceMemberDeclarations InterfaceMemberDeclaration
            //
            case 112: {
                ((InterfaceMemberDeclarationList)getRhsSym(1)).add((IInterfaceMemberDeclaration)getRhsSym(2));
                break;
            } 
            //
            // Rule 113:  InterfaceMemberDeclaration ::= ConstantDeclaration
            //
            case 113:
                break; 
            //
            // Rule 114:  InterfaceMemberDeclaration ::= AbstractMethodDeclaration
            //
            case 114:
                break; 
            //
            // Rule 115:  InterfaceMemberDeclaration ::= ClassDeclaration
            //
            case 115:
                break; 
            //
            // Rule 116:  InterfaceMemberDeclaration ::= InterfaceDeclaration
            //
            case 116:
                break; 
            //
            // Rule 117:  InterfaceMemberDeclaration ::= ;
            //
            case 117: {
                setResult(
                    new EmptyDeclaration(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 118:  ConstantDeclaration ::= FieldDeclaration
            //
            case 118:
                break; 
            //
            // Rule 119:  AbstractMethodDeclaration ::= MethodHeader ;
            //
            case 119: {
                setResult(
                    new AbstractMethodDeclaration(JavaParser.this, getLeftIToken(), getRightIToken(),
                                                  (IMethodHeader)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 120:  ArrayInitializer ::= { VariableInitializersopt Commaopt }
            //
            case 120: {
                setResult(
                    new ArrayInitializer(getLeftIToken(), getRightIToken(),
                                         (VariableInitializerList)getRhsSym(2),
                                         (Commaopt)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 121:  VariableInitializers ::= VariableInitializer
            //
            case 121: {
                setResult(
                    new VariableInitializerList((IVariableInitializer)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 122:  VariableInitializers ::= VariableInitializers , VariableInitializer
            //
            case 122: {
                ((VariableInitializerList)getRhsSym(1)).add((IVariableInitializer)getRhsSym(3));
                break;
            } 
            //
            // Rule 123:  Block ::= { BlockStatementsopt }
            //
            case 123: {
                setResult(
                    new Block(getLeftIToken(), getRightIToken(),
                              (BlockStatementList)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 124:  BlockStatements ::= BlockStatement
            //
            case 124: {
                setResult(
                    new BlockStatementList((IBlockStatement)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 125:  BlockStatements ::= BlockStatements BlockStatement
            //
            case 125: {
                ((BlockStatementList)getRhsSym(1)).add((IBlockStatement)getRhsSym(2));
                break;
            } 
            //
            // Rule 126:  BlockStatement ::= LocalVariableDeclarationStatement
            //
            case 126:
                break; 
            //
            // Rule 127:  BlockStatement ::= Statement
            //
            case 127:
                break; 
            //
            // Rule 128:  BlockStatement ::= ClassDeclaration
            //
            case 128:
                break; 
            //
            // Rule 129:  LocalVariableDeclarationStatement ::= LocalVariableDeclaration ;
            //
            case 129: {
                setResult(
                    new LocalVariableDeclarationStatement(getLeftIToken(), getRightIToken(),
                                                          (LocalVariableDeclaration)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 130:  LocalVariableDeclaration ::= Modifiers Type VariableDeclarators
            //
            case 130: {
                setResult(
                    new LocalVariableDeclaration(JavaParser.this, getLeftIToken(), getRightIToken(),
                                                 (ModifierList)getRhsSym(1),
                                                 (IType)getRhsSym(2),
                                                 (VariableDeclaratorList)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 131:  LocalVariableDeclaration ::= Type VariableDeclarators
            //
            case 131: {
                setResult(
                    new LocalVariableDeclaration(JavaParser.this, getLeftIToken(), getRightIToken(),
                                                 (ModifierList)null,
                                                 (IType)getRhsSym(1),
                                                 (VariableDeclaratorList)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 132:  Statement ::= StatementWithoutTrailingSubstatement
            //
            case 132:
                break; 
            //
            // Rule 133:  Statement ::= LabeledStatement
            //
            case 133:
                break; 
            //
            // Rule 134:  Statement ::= IfThenStatement
            //
            case 134:
                break; 
            //
            // Rule 135:  Statement ::= IfThenElseStatement
            //
            case 135:
                break; 
            //
            // Rule 136:  Statement ::= WhileStatement
            //
            case 136:
                break; 
            //
            // Rule 137:  Statement ::= ForStatement
            //
            case 137:
                break; 
            //
            // Rule 138:  StatementNoShortIf ::= StatementWithoutTrailingSubstatement
            //
            case 138:
                break; 
            //
            // Rule 139:  StatementNoShortIf ::= LabeledStatementNoShortIf
            //
            case 139:
                break; 
            //
            // Rule 140:  StatementNoShortIf ::= IfThenElseStatementNoShortIf
            //
            case 140:
                break; 
            //
            // Rule 141:  StatementNoShortIf ::= WhileStatementNoShortIf
            //
            case 141:
                break; 
            //
            // Rule 142:  StatementNoShortIf ::= ForStatementNoShortIf
            //
            case 142:
                break; 
            //
            // Rule 143:  StatementWithoutTrailingSubstatement ::= Block
            //
            case 143:
                break; 
            //
            // Rule 144:  StatementWithoutTrailingSubstatement ::= EmptyStatement
            //
            case 144:
                break; 
            //
            // Rule 145:  StatementWithoutTrailingSubstatement ::= ExpressionStatement
            //
            case 145:
                break; 
            //
            // Rule 146:  StatementWithoutTrailingSubstatement ::= SwitchStatement
            //
            case 146:
                break; 
            //
            // Rule 147:  StatementWithoutTrailingSubstatement ::= DoStatement
            //
            case 147:
                break; 
            //
            // Rule 148:  StatementWithoutTrailingSubstatement ::= BreakStatement
            //
            case 148:
                break; 
            //
            // Rule 149:  StatementWithoutTrailingSubstatement ::= ContinueStatement
            //
            case 149:
                break; 
            //
            // Rule 150:  StatementWithoutTrailingSubstatement ::= ReturnStatement
            //
            case 150:
                break; 
            //
            // Rule 151:  StatementWithoutTrailingSubstatement ::= SynchronizedStatement
            //
            case 151:
                break; 
            //
            // Rule 152:  StatementWithoutTrailingSubstatement ::= ThrowStatement
            //
            case 152:
                break; 
            //
            // Rule 153:  StatementWithoutTrailingSubstatement ::= TryStatement
            //
            case 153:
                break; 
            //
            // Rule 154:  EmptyStatement ::= ;
            //
            case 154: {
                setResult(
                    new EmptyStatement(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 155:  LabeledStatement ::= IDENTIFIER : Statement
            //
            case 155: {
                setResult(
                    new LabeledStatement(getLeftIToken(), getRightIToken(),
                                         (Ast)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 156:  LabeledStatementNoShortIf ::= IDENTIFIER : StatementNoShortIf$Statement
            //
            case 156: {
                setResult(
                    new LabeledStatement(getLeftIToken(), getRightIToken(),
                                         (Ast)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 157:  ExpressionStatement ::= StatementExpression ;
            //
            case 157: {
                setResult(
                    new ExpressionStatement(getLeftIToken(), getRightIToken(),
                                            (IStatementExpression)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 158:  StatementExpression ::= Assignment
            //
            case 158:
                break; 
            //
            // Rule 159:  StatementExpression ::= PreIncrementExpression
            //
            case 159:
                break; 
            //
            // Rule 160:  StatementExpression ::= PreDecrementExpression
            //
            case 160:
                break; 
            //
            // Rule 161:  StatementExpression ::= PostIncrementExpression
            //
            case 161:
                break; 
            //
            // Rule 162:  StatementExpression ::= PostDecrementExpression
            //
            case 162:
                break; 
            //
            // Rule 163:  StatementExpression ::= MethodInvocation
            //
            case 163:
                break; 
            //
            // Rule 164:  StatementExpression ::= ClassInstanceCreationExpression
            //
            case 164:
                break; 
            //
            // Rule 165:  IfThenStatement ::= if ( Expression ) Statement$thenStmt
            //
            case 165: {
                setResult(
                    new IfStatement(getLeftIToken(), getRightIToken(),
                                    (IExpression)getRhsSym(3),
                                    (Ast)getRhsSym(5),
                                    (Ast)null)
                );
                break;
            } 
            //
            // Rule 166:  IfThenElseStatement ::= if ( Expression ) StatementNoShortIf$thenStmt else Statement$elseStmt
            //
            case 166: {
                setResult(
                    new IfStatement(getLeftIToken(), getRightIToken(),
                                    (IExpression)getRhsSym(3),
                                    (Ast)getRhsSym(5),
                                    (Ast)getRhsSym(7))
                );
                break;
            } 
            //
            // Rule 167:  IfThenElseStatementNoShortIf ::= if ( Expression ) StatementNoShortIf$thenStmt else StatementNoShortIf$elseStmt
            //
            case 167: {
                setResult(
                    new IfStatement(getLeftIToken(), getRightIToken(),
                                    (IExpression)getRhsSym(3),
                                    (Ast)getRhsSym(5),
                                    (Ast)getRhsSym(7))
                );
                break;
            } 
            //
            // Rule 168:  SwitchStatement ::= switch ( Expression ) SwitchBlock
            //
            case 168: {
                setResult(
                    new SwitchStatement(getLeftIToken(), getRightIToken(),
                                        (IExpression)getRhsSym(3),
                                        (SwitchBlock)getRhsSym(5))
                );
                break;
            } 
            //
            // Rule 169:  SwitchBlock ::= { SwitchLabelsopt }
            //
            case 169: {
                setResult(
                    new SwitchBlock(JavaParser.this, getLeftIToken(), getRightIToken(),
                                    (SwitchLabelList)getRhsSym(2),
                                    (SwitchBlockStatementList)null)
                );
                break;
            } 
            //
            // Rule 170:  SwitchBlock ::= { SwitchBlockStatements SwitchLabelsopt }
            //
            case 170: {
                setResult(
                    new SwitchBlock(JavaParser.this, getLeftIToken(), getRightIToken(),
                                    (SwitchLabelList)getRhsSym(3),
                                    (SwitchBlockStatementList)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 171:  SwitchBlockStatements ::= SwitchBlockStatement
            //
            case 171: {
                setResult(
                    new SwitchBlockStatementList((SwitchBlockStatement)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 172:  SwitchBlockStatements ::= SwitchBlockStatements SwitchBlockStatement
            //
            case 172: {
                ((SwitchBlockStatementList)getRhsSym(1)).add((SwitchBlockStatement)getRhsSym(2));
                break;
            } 
            //
            // Rule 173:  SwitchBlockStatement ::= SwitchLabels BlockStatements
            //
            case 173: {
                setResult(
                    new SwitchBlockStatement(getLeftIToken(), getRightIToken(),
                                             (SwitchLabelList)getRhsSym(1),
                                             (BlockStatementList)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 174:  SwitchLabels ::= SwitchLabel
            //
            case 174: {
                setResult(
                    new SwitchLabelList((ISwitchLabel)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 175:  SwitchLabels ::= SwitchLabels SwitchLabel
            //
            case 175: {
                ((SwitchLabelList)getRhsSym(1)).add((ISwitchLabel)getRhsSym(2));
                break;
            } 
            //
            // Rule 176:  SwitchLabel ::= case ConstantExpression :
            //
            case 176: {
                setResult(
                    new CaseLabel(getLeftIToken(), getRightIToken(),
                                  (IConstantExpression)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 177:  SwitchLabel ::= default :
            //
            case 177: {
                setResult(
                    new DefaultLabel(getLeftIToken(), getRightIToken())
                );
                break;
            } 
            //
            // Rule 178:  WhileStatement ::= while ( Expression ) Statement
            //
            case 178: {
                setResult(
                    new WhileStatement(getLeftIToken(), getRightIToken(),
                                       (IExpression)getRhsSym(3),
                                       (Ast)getRhsSym(5))
                );
                break;
            } 
            //
            // Rule 179:  WhileStatementNoShortIf ::= while ( Expression ) StatementNoShortIf$Statement
            //
            case 179: {
                setResult(
                    new WhileStatement(getLeftIToken(), getRightIToken(),
                                       (IExpression)getRhsSym(3),
                                       (Ast)getRhsSym(5))
                );
                break;
            } 
            //
            // Rule 180:  DoStatement ::= do Statement while ( Expression ) ;
            //
            case 180: {
                setResult(
                    new DoStatement(getLeftIToken(), getRightIToken(),
                                    (IStatement)getRhsSym(2),
                                    (IExpression)getRhsSym(5))
                );
                break;
            } 
            //
            // Rule 181:  ForStatement ::= for ( ForInitopt ; Expressionopt ; ForUpdateopt ) Statement
            //
            case 181: {
                setResult(
                    new ForStatement(getLeftIToken(), getRightIToken(),
                                     (IForInitopt)getRhsSym(3),
                                     (IExpressionopt)getRhsSym(5),
                                     (StatementExpressionList)getRhsSym(7),
                                     (Ast)getRhsSym(9))
                );
                break;
            } 
            //
            // Rule 182:  ForStatementNoShortIf ::= for ( ForInitopt ; Expressionopt ; ForUpdateopt ) StatementNoShortIf$Statement
            //
            case 182: {
                setResult(
                    new ForStatement(getLeftIToken(), getRightIToken(),
                                     (IForInitopt)getRhsSym(3),
                                     (IExpressionopt)getRhsSym(5),
                                     (StatementExpressionList)getRhsSym(7),
                                     (Ast)getRhsSym(9))
                );
                break;
            } 
            //
            // Rule 183:  ForInit ::= StatementExpressionList
            //
            case 183:
                break; 
            //
            // Rule 184:  ForInit ::= LocalVariableDeclaration
            //
            case 184:
                break; 
            //
            // Rule 185:  ForUpdate ::= StatementExpressionList
            //
            case 185:
                break; 
            //
            // Rule 186:  StatementExpressionList ::= StatementExpression
            //
            case 186: {
                setResult(
                    new StatementExpressionList((IStatementExpression)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 187:  StatementExpressionList ::= StatementExpressionList , StatementExpression
            //
            case 187: {
                ((StatementExpressionList)getRhsSym(1)).add((IStatementExpression)getRhsSym(3));
                break;
            } 
            //
            // Rule 188:  BreakStatement ::= break IDENTIFIERopt ;
            //
            case 188: {
                setResult(
                    new BreakStatement(getLeftIToken(), getRightIToken(),
                                       (IDENTIFIERopt)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 189:  ContinueStatement ::= continue IDENTIFIERopt ;
            //
            case 189: {
                setResult(
                    new ContinueStatement(getLeftIToken(), getRightIToken(),
                                          (IDENTIFIERopt)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 190:  ReturnStatement ::= return Expressionopt ;
            //
            case 190: {
                setResult(
                    new ReturnStatement(getLeftIToken(), getRightIToken(),
                                        (IExpressionopt)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 191:  ThrowStatement ::= throw Expression ;
            //
            case 191: {
                setResult(
                    new ThrowStatement(getLeftIToken(), getRightIToken(),
                                       (IExpression)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 192:  SynchronizedStatement ::= synchronized ( Expression ) Block
            //
            case 192: {
                setResult(
                    new SynchronizedStatement(getLeftIToken(), getRightIToken(),
                                              (IExpression)getRhsSym(3),
                                              (Block)getRhsSym(5))
                );
                break;
            } 
            //
            // Rule 193:  TryStatement ::= try Block Catches$Catchesopt
            //
            case 193: {
                setResult(
                    new TryStatement(getLeftIToken(), getRightIToken(),
                                     (Block)getRhsSym(2),
                                     (Ast)getRhsSym(3),
                                     (Finally)null)
                );
                break;
            } 
            //
            // Rule 194:  TryStatement ::= try Block Catchesopt Finally
            //
            case 194: {
                setResult(
                    new TryStatement(getLeftIToken(), getRightIToken(),
                                     (Block)getRhsSym(2),
                                     (Ast)getRhsSym(3),
                                     (Finally)getRhsSym(4))
                );
                break;
            } 
            //
            // Rule 195:  Catches ::= CatchClause
            //
            case 195: {
                setResult(
                    new CatchClauseList((CatchClause)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 196:  Catches ::= Catches CatchClause
            //
            case 196: {
                ((CatchClauseList)getRhsSym(1)).add((CatchClause)getRhsSym(2));
                break;
            } 
            //
            // Rule 197:  CatchClause ::= catch ( FormalParameter ) Block
            //
            case 197: {
                setResult(
                    new CatchClause(getLeftIToken(), getRightIToken(),
                                    (FormalParameter)getRhsSym(3),
                                    (Block)getRhsSym(5))
                );
                break;
            } 
            //
            // Rule 198:  Finally ::= finally Block
            //
            case 198: {
                setResult(
                    new Finally(getLeftIToken(), getRightIToken(),
                                (Block)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 199:  Primary ::= PrimaryNoNewArray
            //
            case 199:
                break; 
            //
            // Rule 200:  Primary ::= ArrayCreationExpression
            //
            case 200:
                break; 
            //
            // Rule 201:  PrimaryNoNewArray ::= Literal
            //
            case 201:
                break; 
            //
            // Rule 202:  PrimaryNoNewArray ::= MethodInvocation
            //
            case 202:
                break; 
            //
            // Rule 203:  PrimaryNoNewArray ::= ArrayAccess
            //
            case 203:
                break; 
            //
            // Rule 204:  PrimaryNoNewArray ::= ClassInstanceCreationExpression
            //
            case 204:
                break; 
            //
            // Rule 205:  PrimaryNoNewArray ::= FieldAccess
            //
            case 205:
                break; 
            //
            // Rule 206:  PrimaryNoNewArray ::= ( Expression )
            //
            case 206: {
                setResult(
                    new ParenthesizedExpression(getLeftIToken(), getRightIToken(),
                                                (IExpression)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 207:  PrimaryNoNewArray ::= this
            //
            case 207: {
                setResult(
                    new PrimaryThis(getLeftIToken(), getRightIToken(),
                                    (IName)null)
                );
                break;
            } 
            //
            // Rule 208:  PrimaryNoNewArray ::= Name . this
            //
            case 208: {
                setResult(
                    new PrimaryThis(getLeftIToken(), getRightIToken(),
                                    (IName)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 209:  PrimaryNoNewArray ::= Type . class
            //
            case 209: {
                setResult(
                    new PrimaryClassLiteral(getLeftIToken(), getRightIToken(),
                                            (IType)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 210:  PrimaryNoNewArray ::= void . class
            //
            case 210: {
                setResult(
                    new PrimaryVoidClassLiteral(getLeftIToken(), getRightIToken())
                );
                break;
            } 
            //
            // Rule 211:  ClassInstanceCreationExpression ::= new ClassType ( ArgumentListopt ) ClassBodyopt
            //
            case 211: {
                setResult(
                    new ClassInstanceCreationExpression(getLeftIToken(), getRightIToken(),
                                                        (IClassType)getRhsSym(2),
                                                        (ExpressionList)getRhsSym(4),
                                                        (ClassBody)getRhsSym(6),
                                                        (IPostfixExpression)null)
                );
                break;
            } 
            //
            // Rule 212:  ClassInstanceCreationExpression ::= Primary$expression . new SimpleName$ClassType ( ArgumentListopt ) ClassBodyopt
            //
            case 212: {
                setResult(
                    new ClassInstanceCreationExpression(getLeftIToken(), getRightIToken(),
                                                        (IClassType)getRhsSym(4),
                                                        (ExpressionList)getRhsSym(6),
                                                        (ClassBody)getRhsSym(8),
                                                        (IPostfixExpression)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 213:  ClassInstanceCreationExpression ::= Name$expression . new SimpleName$ClassType ( ArgumentListopt ) ClassBodyopt
            //
            case 213: {
                setResult(
                    new ClassInstanceCreationExpression(getLeftIToken(), getRightIToken(),
                                                        (IClassType)getRhsSym(4),
                                                        (ExpressionList)getRhsSym(6),
                                                        (ClassBody)getRhsSym(8),
                                                        (IPostfixExpression)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 214:  ArgumentList ::= Expression
            //
            case 214: {
                setResult(
                    new ExpressionList((IExpression)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 215:  ArgumentList ::= ArgumentList , Expression
            //
            case 215: {
                ((ExpressionList)getRhsSym(1)).add((IExpression)getRhsSym(3));
                break;
            } 
            //
            // Rule 216:  ArrayCreationExpression ::= new PrimitiveType$Type DimExprs Dimsopt
            //
            case 216: {
                setResult(
                    new ArrayCreationExpression(getLeftIToken(), getRightIToken(),
                                                (IType)getRhsSym(2),
                                                (DimExprList)getRhsSym(3),
                                                (DimList)getRhsSym(4),
                                                (ArrayInitializer)null)
                );
                break;
            } 
            //
            // Rule 217:  ArrayCreationExpression ::= new ClassOrInterfaceType$Type DimExprs Dimsopt
            //
            case 217: {
                setResult(
                    new ArrayCreationExpression(getLeftIToken(), getRightIToken(),
                                                (IType)getRhsSym(2),
                                                (DimExprList)getRhsSym(3),
                                                (DimList)getRhsSym(4),
                                                (ArrayInitializer)null)
                );
                break;
            } 
            //
            // Rule 218:  ArrayCreationExpression ::= new ArrayType$Type ArrayInitializer
            //
            case 218: {
                setResult(
                    new ArrayCreationExpression(getLeftIToken(), getRightIToken(),
                                                (IType)getRhsSym(2),
                                                (DimExprList)null,
                                                (DimList)null,
                                                (ArrayInitializer)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 219:  DimExprs ::= DimExpr
            //
            case 219: {
                setResult(
                    new DimExprList((DimExpr)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 220:  DimExprs ::= DimExprs DimExpr
            //
            case 220: {
                ((DimExprList)getRhsSym(1)).add((DimExpr)getRhsSym(2));
                break;
            } 
            //
            // Rule 221:  DimExpr ::= [ Expression ]
            //
            case 221: {
                setResult(
                    new DimExpr(getLeftIToken(), getRightIToken(),
                                (IExpression)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 222:  Dims ::= Dim
            //
            case 222: {
                setResult(
                    new DimList((Dim)getRhsSym(1), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 223:  Dims ::= Dims Dim
            //
            case 223: {
                ((DimList)getRhsSym(1)).add((Dim)getRhsSym(2));
                break;
            } 
            //
            // Rule 224:  Dim ::= [ ]
            //
            case 224: {
                setResult(
                    new Dim(getLeftIToken(), getRightIToken())
                );
                break;
            } 
            //
            // Rule 225:  FieldAccess ::= Primary . IDENTIFIER
            //
            case 225: {
                setResult(
                    new FieldAccess(getLeftIToken(), getRightIToken(),
                                    (IPrimary)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 226:  FieldAccess ::= super . IDENTIFIER
            //
            case 226: {
                setResult(
                    new SuperFieldAccess(getLeftIToken(), getRightIToken(),
                                         (IName)null)
                );
                break;
            } 
            //
            // Rule 227:  FieldAccess ::= Name . super . IDENTIFIER
            //
            case 227: {
                setResult(
                    new SuperFieldAccess(getLeftIToken(), getRightIToken(),
                                         (IName)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 228:  MethodInvocation ::= Name ( ArgumentListopt )
            //
            case 228: {
                setResult(
                    new MethodInvocation(getLeftIToken(), getRightIToken(),
                                         (IName)getRhsSym(1),
                                         (ExpressionList)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 229:  MethodInvocation ::= Primary . IDENTIFIER ( ArgumentListopt )
            //
            case 229: {
                setResult(
                    new PrimaryMethodInvocation(getLeftIToken(), getRightIToken(),
                                                (IPrimary)getRhsSym(1),
                                                (ExpressionList)getRhsSym(5))
                );
                break;
            } 
            //
            // Rule 230:  MethodInvocation ::= super . IDENTIFIER ( ArgumentListopt )
            //
            case 230: {
                setResult(
                    new SuperMethodInvocation(getLeftIToken(), getRightIToken(),
                                              (ExpressionList)getRhsSym(5),
                                              (IName)null)
                );
                break;
            } 
            //
            // Rule 231:  MethodInvocation ::= Name . super . IDENTIFIER ( ArgumentListopt )
            //
            case 231: {
                setResult(
                    new SuperMethodInvocation(getLeftIToken(), getRightIToken(),
                                              (ExpressionList)getRhsSym(7),
                                              (IName)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 232:  ArrayAccess ::= Name$Base [ Expression ]
            //
            case 232: {
                setResult(
                    new ArrayAccess(getLeftIToken(), getRightIToken(),
                                    (IPostfixExpression)getRhsSym(1),
                                    (IExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 233:  ArrayAccess ::= PrimaryNoNewArray$Base [ Expression ]
            //
            case 233: {
                setResult(
                    new ArrayAccess(getLeftIToken(), getRightIToken(),
                                    (IPostfixExpression)getRhsSym(1),
                                    (IExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 234:  PostfixExpression ::= Primary
            //
            case 234:
                break; 
            //
            // Rule 235:  PostfixExpression ::= Name
            //
            case 235:
                break; 
            //
            // Rule 236:  PostfixExpression ::= PostIncrementExpression
            //
            case 236:
                break; 
            //
            // Rule 237:  PostfixExpression ::= PostDecrementExpression
            //
            case 237:
                break; 
            //
            // Rule 238:  PostIncrementExpression ::= PostfixExpression ++
            //
            case 238: {
                setResult(
                    new PostIncrementExpression(getLeftIToken(), getRightIToken(),
                                                (IPostfixExpression)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 239:  PostDecrementExpression ::= PostfixExpression --
            //
            case 239: {
                setResult(
                    new PostDecrementExpression(getLeftIToken(), getRightIToken(),
                                                (IPostfixExpression)getRhsSym(1))
                );
                break;
            } 
            //
            // Rule 240:  UnaryExpression ::= PreIncrementExpression
            //
            case 240:
                break; 
            //
            // Rule 241:  UnaryExpression ::= PreDecrementExpression
            //
            case 241:
                break; 
            //
            // Rule 242:  UnaryExpression ::= UnaryExpressionNotPlusMinus
            //
            case 242:
                break; 
            //
            // Rule 243:  UnaryExpression ::= + UnaryExpression
            //
            case 243: {
                setResult(
                    new PlusUnaryExpression(getLeftIToken(), getRightIToken(),
                                            (IUnaryExpression)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 244:  UnaryExpression ::= - UnaryExpression
            //
            case 244: {
                setResult(
                    new MinusUnaryExpression(getLeftIToken(), getRightIToken(),
                                             (IUnaryExpression)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 245:  PreIncrementExpression ::= ++ UnaryExpression
            //
            case 245: {
                setResult(
                    new PreIncrementExpression(getLeftIToken(), getRightIToken(),
                                               (IUnaryExpression)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 246:  PreDecrementExpression ::= -- UnaryExpression
            //
            case 246: {
                setResult(
                    new PreDecrementExpression(getLeftIToken(), getRightIToken(),
                                               (IUnaryExpression)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 247:  UnaryExpressionNotPlusMinus ::= PostfixExpression
            //
            case 247:
                break; 
            //
            // Rule 248:  UnaryExpressionNotPlusMinus ::= CastExpression
            //
            case 248:
                break; 
            //
            // Rule 249:  UnaryExpressionNotPlusMinus ::= ~ UnaryExpression
            //
            case 249: {
                setResult(
                    new UnaryComplementExpression(getLeftIToken(), getRightIToken(),
                                                  (IUnaryExpression)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 250:  UnaryExpressionNotPlusMinus ::= ! UnaryExpression
            //
            case 250: {
                setResult(
                    new UnaryNotExpression(getLeftIToken(), getRightIToken(),
                                           (IUnaryExpression)getRhsSym(2))
                );
                break;
            } 
            //
            // Rule 251:  CastExpression ::= ( PrimitiveType Dimsopt ) UnaryExpression
            //
            case 251: {
                setResult(
                    new PrimitiveCastExpression(getLeftIToken(), getRightIToken(),
                                                (IPrimitiveType)getRhsSym(2),
                                                (DimList)getRhsSym(3),
                                                (IUnaryExpression)getRhsSym(5))
                );
                break;
            } 
            //
            // Rule 252:  CastExpression ::= ( Expression$Name ) UnaryExpressionNotPlusMinus
            //
            case 252: {
                setResult(
                    new ClassCastExpression(getLeftIToken(), getRightIToken(),
                                            (IExpression)getRhsSym(2),
                                            (IUnaryExpressionNotPlusMinus)getRhsSym(4),
                                            (DimList)null)
                );
                break;
            } 
            //
            // Rule 253:  CastExpression ::= ( Name$Name Dims ) UnaryExpressionNotPlusMinus
            //
            case 253: {
                setResult(
                    new ClassCastExpression(getLeftIToken(), getRightIToken(),
                                            (IExpression)getRhsSym(2),
                                            (IUnaryExpressionNotPlusMinus)getRhsSym(5),
                                            (DimList)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 254:  MultiplicativeExpression ::= UnaryExpression
            //
            case 254:
                break; 
            //
            // Rule 255:  MultiplicativeExpression ::= MultiplicativeExpression * UnaryExpression
            //
            case 255: {
                setResult(
                    new MultiplyExpression(getLeftIToken(), getRightIToken(),
                                           (IMultiplicativeExpression)getRhsSym(1),
                                           (IUnaryExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 256:  MultiplicativeExpression ::= MultiplicativeExpression / UnaryExpression
            //
            case 256: {
                setResult(
                    new DivideExpression(getLeftIToken(), getRightIToken(),
                                         (IMultiplicativeExpression)getRhsSym(1),
                                         (IUnaryExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 257:  MultiplicativeExpression ::= MultiplicativeExpression % UnaryExpression
            //
            case 257: {
                setResult(
                    new ModExpression(getLeftIToken(), getRightIToken(),
                                      (IMultiplicativeExpression)getRhsSym(1),
                                      (IUnaryExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 258:  AdditiveExpression ::= MultiplicativeExpression
            //
            case 258:
                break; 
            //
            // Rule 259:  AdditiveExpression ::= AdditiveExpression + MultiplicativeExpression
            //
            case 259: {
                setResult(
                    new AddExpression(getLeftIToken(), getRightIToken(),
                                      (IAdditiveExpression)getRhsSym(1),
                                      (IMultiplicativeExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 260:  AdditiveExpression ::= AdditiveExpression - MultiplicativeExpression
            //
            case 260: {
                setResult(
                    new SubtractExpression(getLeftIToken(), getRightIToken(),
                                           (IAdditiveExpression)getRhsSym(1),
                                           (IMultiplicativeExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 261:  ShiftExpression ::= AdditiveExpression
            //
            case 261:
                break; 
            //
            // Rule 262:  ShiftExpression ::= ShiftExpression << AdditiveExpression
            //
            case 262: {
                setResult(
                    new LeftShiftExpression(getLeftIToken(), getRightIToken(),
                                            (IShiftExpression)getRhsSym(1),
                                            (IAdditiveExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 263:  ShiftExpression ::= ShiftExpression >> AdditiveExpression
            //
            case 263: {
                setResult(
                    new RightShiftExpression(getLeftIToken(), getRightIToken(),
                                             (IShiftExpression)getRhsSym(1),
                                             (IAdditiveExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 264:  ShiftExpression ::= ShiftExpression >>> AdditiveExpression
            //
            case 264: {
                setResult(
                    new UnsignedRightShiftExpression(getLeftIToken(), getRightIToken(),
                                                     (IShiftExpression)getRhsSym(1),
                                                     (IAdditiveExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 265:  RelationalExpression ::= ShiftExpression
            //
            case 265:
                break; 
            //
            // Rule 266:  RelationalExpression ::= RelationalExpression < ShiftExpression
            //
            case 266: {
                setResult(
                    new LessExpression(getLeftIToken(), getRightIToken(),
                                       (IRelationalExpression)getRhsSym(1),
                                       (IShiftExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 267:  RelationalExpression ::= RelationalExpression > ShiftExpression
            //
            case 267: {
                setResult(
                    new GreaterExpression(getLeftIToken(), getRightIToken(),
                                          (IRelationalExpression)getRhsSym(1),
                                          (IShiftExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 268:  RelationalExpression ::= RelationalExpression <= ShiftExpression
            //
            case 268: {
                setResult(
                    new LessEqualExpression(getLeftIToken(), getRightIToken(),
                                            (IRelationalExpression)getRhsSym(1),
                                            (IShiftExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 269:  RelationalExpression ::= RelationalExpression >= ShiftExpression
            //
            case 269: {
                setResult(
                    new GreaterEqualExpression(getLeftIToken(), getRightIToken(),
                                               (IRelationalExpression)getRhsSym(1),
                                               (IShiftExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 270:  RelationalExpression ::= RelationalExpression instanceof ReferenceType
            //
            case 270: {
                setResult(
                    new InstanceofExpression(getLeftIToken(), getRightIToken(),
                                             (IRelationalExpression)getRhsSym(1),
                                             (IReferenceType)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 271:  EqualityExpression ::= RelationalExpression
            //
            case 271:
                break; 
            //
            // Rule 272:  EqualityExpression ::= EqualityExpression == RelationalExpression
            //
            case 272: {
                setResult(
                    new EqualExpression(getLeftIToken(), getRightIToken(),
                                        (IEqualityExpression)getRhsSym(1),
                                        (IRelationalExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 273:  EqualityExpression ::= EqualityExpression != RelationalExpression
            //
            case 273: {
                setResult(
                    new NotEqualExpression(getLeftIToken(), getRightIToken(),
                                           (IEqualityExpression)getRhsSym(1),
                                           (IRelationalExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 274:  AndExpression ::= EqualityExpression
            //
            case 274:
                break; 
            //
            // Rule 275:  AndExpression ::= AndExpression & EqualityExpression
            //
            case 275: {
                setResult(
                    new AndExpression(getLeftIToken(), getRightIToken(),
                                      (IAndExpression)getRhsSym(1),
                                      (IEqualityExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 276:  ExclusiveOrExpression ::= AndExpression
            //
            case 276:
                break; 
            //
            // Rule 277:  ExclusiveOrExpression ::= ExclusiveOrExpression ^ AndExpression
            //
            case 277: {
                setResult(
                    new ExclusiveOrExpression(getLeftIToken(), getRightIToken(),
                                              (IExclusiveOrExpression)getRhsSym(1),
                                              (IAndExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 278:  InclusiveOrExpression ::= ExclusiveOrExpression
            //
            case 278:
                break; 
            //
            // Rule 279:  InclusiveOrExpression ::= InclusiveOrExpression | ExclusiveOrExpression
            //
            case 279: {
                setResult(
                    new InclusiveOrExpression(getLeftIToken(), getRightIToken(),
                                              (IInclusiveOrExpression)getRhsSym(1),
                                              (IExclusiveOrExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 280:  ConditionalAndExpression ::= InclusiveOrExpression
            //
            case 280:
                break; 
            //
            // Rule 281:  ConditionalAndExpression ::= ConditionalAndExpression && InclusiveOrExpression
            //
            case 281: {
                setResult(
                    new ConditionalAndExpression(getLeftIToken(), getRightIToken(),
                                                 (IConditionalAndExpression)getRhsSym(1),
                                                 (IInclusiveOrExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 282:  ConditionalOrExpression ::= ConditionalAndExpression
            //
            case 282:
                break; 
            //
            // Rule 283:  ConditionalOrExpression ::= ConditionalOrExpression || ConditionalAndExpression
            //
            case 283: {
                setResult(
                    new ConditionalOrExpression(getLeftIToken(), getRightIToken(),
                                                (IConditionalOrExpression)getRhsSym(1),
                                                (IConditionalAndExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 284:  ConditionalExpression ::= ConditionalOrExpression
            //
            case 284:
                break; 
            //
            // Rule 285:  ConditionalExpression ::= ConditionalOrExpression ? Expression : ConditionalExpression
            //
            case 285: {
                setResult(
                    new ConditionalExpression(getLeftIToken(), getRightIToken(),
                                              (IConditionalOrExpression)getRhsSym(1),
                                              (IExpression)getRhsSym(3),
                                              (IConditionalExpression)getRhsSym(5))
                );
                break;
            } 
            //
            // Rule 286:  AssignmentExpression ::= ConditionalExpression
            //
            case 286:
                break; 
            //
            // Rule 287:  AssignmentExpression ::= Assignment
            //
            case 287:
                break; 
            //
            // Rule 288:  Assignment ::= LeftHandSide AssignmentOperator AssignmentExpression
            //
            case 288: {
                setResult(
                    new Assignment(getLeftIToken(), getRightIToken(),
                                   (ILeftHandSide)getRhsSym(1),
                                   (IAssignmentOperator)getRhsSym(2),
                                   (IAssignmentExpression)getRhsSym(3))
                );
                break;
            } 
            //
            // Rule 289:  LeftHandSide ::= Name
            //
            case 289:
                break; 
            //
            // Rule 290:  LeftHandSide ::= FieldAccess
            //
            case 290:
                break; 
            //
            // Rule 291:  LeftHandSide ::= ArrayAccess
            //
            case 291:
                break; 
            //
            // Rule 292:  AssignmentOperator ::= =
            //
            case 292: {
                setResult(
                    new EqualOperator(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 293:  AssignmentOperator ::= *=
            //
            case 293: {
                setResult(
                    new MultiplyEqualOperator(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 294:  AssignmentOperator ::= /=
            //
            case 294: {
                setResult(
                    new DivideEqualOperator(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 295:  AssignmentOperator ::= %=
            //
            case 295: {
                setResult(
                    new ModEqualOperator(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 296:  AssignmentOperator ::= +=
            //
            case 296: {
                setResult(
                    new PlusEqualOperator(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 297:  AssignmentOperator ::= -=
            //
            case 297: {
                setResult(
                    new MinusEqualOperator(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 298:  AssignmentOperator ::= <<=
            //
            case 298: {
                setResult(
                    new LeftShiftEqualOperator(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 299:  AssignmentOperator ::= >>=
            //
            case 299: {
                setResult(
                    new RightShiftEqualOperator(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 300:  AssignmentOperator ::= >>>=
            //
            case 300: {
                setResult(
                    new UnsignedRightShiftEqualOperator(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 301:  AssignmentOperator ::= &=
            //
            case 301: {
                setResult(
                    new AndEqualOperator(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 302:  AssignmentOperator ::= ^=
            //
            case 302: {
                setResult(
                    new ExclusiveOrEqualOperator(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 303:  AssignmentOperator ::= |=
            //
            case 303: {
                setResult(
                    new OrEqualOperator(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 304:  Expression ::= AssignmentExpression
            //
            case 304:
                break; 
            //
            // Rule 305:  ConstantExpression ::= Expression
            //
            case 305:
                break; 
            //
            // Rule 306:  PackageDeclarationopt ::= $Empty
            //
            case 306: {
                setResult(null);
                break;
            } 
            //
            // Rule 307:  PackageDeclarationopt ::= PackageDeclaration
            //
            case 307:
                break; 
            //
            // Rule 308:  Superopt ::= $Empty
            //
            case 308: {
                setResult(null);
                break;
            } 
            //
            // Rule 309:  Superopt ::= Super
            //
            case 309:
                break; 
            //
            // Rule 310:  Expressionopt ::= $Empty
            //
            case 310: {
                setResult(null);
                break;
            } 
            //
            // Rule 311:  Expressionopt ::= Expression
            //
            case 311:
                break; 
            //
            // Rule 312:  ClassBodyopt ::= $Empty
            //
            case 312: {
                setResult(null);
                break;
            } 
            //
            // Rule 313:  ClassBodyopt ::= ClassBody
            //
            case 313:
                break; 
            //
            // Rule 314:  ImportDeclarationsopt ::= $Empty
            //
            case 314: {
                setResult(
                    new ImportDeclarationList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 315:  ImportDeclarationsopt ::= ImportDeclarations
            //
            case 315:
                break; 
            //
            // Rule 316:  TypeDeclarationsopt ::= $Empty
            //
            case 316: {
                setResult(
                    new TypeDeclarationList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 317:  TypeDeclarationsopt ::= TypeDeclarations
            //
            case 317:
                break; 
            //
            // Rule 318:  ClassBodyDeclarationsopt ::= $Empty
            //
            case 318: {
                setResult(
                    new ClassBodyDeclarationList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 319:  ClassBodyDeclarationsopt ::= ClassBodyDeclarations
            //
            case 319:
                break; 
            //
            // Rule 320:  Modifiersopt ::= $Empty
            //
            case 320: {
                setResult(
                    new ModifierList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 321:  Modifiersopt ::= Modifiers
            //
            case 321:
                break; 
            //
            // Rule 322:  BlockStatementsopt ::= $Empty
            //
            case 322: {
                setResult(
                    new BlockStatementList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 323:  BlockStatementsopt ::= BlockStatements
            //
            case 323:
                break; 
            //
            // Rule 324:  Dimsopt ::= $Empty
            //
            case 324: {
                setResult(
                    new DimList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 325:  Dimsopt ::= Dims
            //
            case 325:
                break; 
            //
            // Rule 326:  ArgumentListopt ::= $Empty
            //
            case 326: {
                setResult(
                    new ExpressionList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 327:  ArgumentListopt ::= ArgumentList
            //
            case 327:
                break; 
            //
            // Rule 328:  Throwsopt ::= $Empty
            //
            case 328: {
                setResult(
                    new ClassTypeList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 329:  Throwsopt ::= Throws
            //
            case 329:
                break; 
            //
            // Rule 330:  FormalParameterListopt ::= $Empty
            //
            case 330: {
                setResult(
                    new FormalParameterList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 331:  FormalParameterListopt ::= FormalParameterList
            //
            case 331:
                break; 
            //
            // Rule 332:  Interfacesopt ::= $Empty
            //
            case 332: {
                setResult(
                    new InterfaceTypeList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 333:  Interfacesopt ::= Interfaces
            //
            case 333:
                break; 
            //
            // Rule 334:  InterfaceMemberDeclarationsopt ::= $Empty
            //
            case 334: {
                setResult(
                    new InterfaceMemberDeclarationList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 335:  InterfaceMemberDeclarationsopt ::= InterfaceMemberDeclarations
            //
            case 335:
                break; 
            //
            // Rule 336:  ForInitopt ::= $Empty
            //
            case 336: {
                setResult(null);
                break;
            } 
            //
            // Rule 337:  ForInitopt ::= ForInit
            //
            case 337:
                break; 
            //
            // Rule 338:  ForUpdateopt ::= $Empty
            //
            case 338: {
                setResult(
                    new StatementExpressionList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 339:  ForUpdateopt ::= ForUpdate
            //
            case 339:
                break; 
            //
            // Rule 340:  ExtendsInterfacesopt ::= $Empty
            //
            case 340: {
                setResult(
                    new InterfaceTypeList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 341:  ExtendsInterfacesopt ::= ExtendsInterfaces
            //
            case 341:
                break; 
            //
            // Rule 342:  Catchesopt ::= $Empty
            //
            case 342: {
                setResult(
                    new CatchClauseList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 343:  Catchesopt ::= Catches
            //
            case 343:
                break; 
            //
            // Rule 344:  VariableInitializersopt ::= $Empty
            //
            case 344: {
                setResult(
                    new VariableInitializerList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 345:  VariableInitializersopt ::= VariableInitializers
            //
            case 345:
                break; 
            //
            // Rule 346:  SwitchLabelsopt ::= $Empty
            //
            case 346: {
                setResult(
                    new SwitchLabelList(getLeftIToken(), getRightIToken(), true /* left recursive */)
                );
                break;
            } 
            //
            // Rule 347:  SwitchLabelsopt ::= SwitchLabels
            //
            case 347:
                break; 
            //
            // Rule 348:  Commaopt ::= $Empty
            //
            case 348: {
                setResult(null);
                break;
            } 
            //
            // Rule 349:  Commaopt ::= ,
            //
            case 349: {
                setResult(
                    new Commaopt(getRhsIToken(1))
                );
                break;
            } 
            //
            // Rule 350:  IDENTIFIERopt ::= $Empty
            //
            case 350: {
                setResult(null);
                break;
            } 
            //
            // Rule 351:  IDENTIFIERopt ::= IDENTIFIER
            //
            case 351: {
                setResult(
                    new IDENTIFIERopt(getRhsIToken(1))
                );
                break;
            }
    
            default:
                break;
        }
        return;
    }
}

