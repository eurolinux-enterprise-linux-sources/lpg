/*
This is a test

*/
class a123  { int x = (a==b);}
