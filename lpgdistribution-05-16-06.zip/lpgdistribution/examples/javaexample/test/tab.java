/	junk
interface tab
{
	contains	tabs;	and_a_few_mistakes;
	int tab	= tab_without_terminating_semicolon;
	***********/
	int a = b;
	int start =
	int last = good;
	int method()
	{
        if (a == b)
        else b = a;
	}
}

class x { 