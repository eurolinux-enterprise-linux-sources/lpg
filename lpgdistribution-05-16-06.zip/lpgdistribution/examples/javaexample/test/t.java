public class class extends extends implements implements
{ 
    public final abstract void abstrac() throws cas, defaul
    {
        boolean boolean;
        byte byte;
        char char;
        int int;
        long long;
        float float;
        double double;

        for: for (int int; package == static; int++)
        {
            continue: continue = break;
            if: if (throws != throw)
                 do: do = final;
            else if = public;
        }
        catch: catch = protected;
    }
}
