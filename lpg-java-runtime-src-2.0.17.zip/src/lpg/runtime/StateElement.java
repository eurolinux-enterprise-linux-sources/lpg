package lpg.runtime;

public class StateElement
{
    StateElement parent,
                 children,
                 siblings;
    int number;
};

