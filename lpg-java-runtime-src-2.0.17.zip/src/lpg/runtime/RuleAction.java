package lpg.runtime;

public interface RuleAction
{
    void ruleAction(int ruleNumber);
}
