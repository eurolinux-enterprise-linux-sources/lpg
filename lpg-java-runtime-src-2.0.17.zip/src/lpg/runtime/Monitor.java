package lpg.runtime;

public interface Monitor
{
    public abstract boolean isCancelled();
}
